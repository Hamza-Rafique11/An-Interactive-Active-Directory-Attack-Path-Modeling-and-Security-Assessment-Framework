import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Lock,
  Crosshair,
  Server,
  Route,
  AlertTriangle,
  FileCheck2,
  CheckCircle2,
  Terminal,
  Activity,
  Layers,
  ArrowRight,
  Database,
  Cpu,
  FileText,
  Radio,
  ListTree,
  Network,
  KeyRound,
  TrendingUp,
  GitFork,
  Sliders
} from 'lucide-react';
import { HeaderScopeBar } from './components/HeaderScopeBar';
import { ToneSelectorBar } from './components/ToneSelectorBar';
import { SidebarNav } from './components/SidebarNav';
import { AttackGraphPreview } from './components/AttackGraphPreview';
import { TerminalWidget } from './components/TerminalWidget';
import { ProgrammerCmdWorkbench } from './components/ProgrammerCmdWorkbench';
import { TargetTableWidget } from './components/TargetTableWidget';
import { FindingsSummaryWidget } from './components/FindingsSummaryWidget';
import { PhaseRoadmapModal } from './components/PhaseRoadmapModal';
import { ScopeVerificationView } from './components/ScopeVerificationView';
import { EvidenceVaultView } from './components/EvidenceVaultView';
import { AuditLogView } from './components/AuditLogView';
import { ExecutiveReportView } from './components/ExecutiveReportView';
import { HostDiscoveryView } from './components/HostDiscoveryView';
import { PortEnumerationView } from './components/PortEnumerationView';
import { ActiveDirectoryView } from './components/ActiveDirectoryView';
import { CredentialsValidationView } from './components/CredentialsValidationView';
import { PrivilegeEscalationView } from './components/PrivilegeEscalationView';
import { LateralMovementView } from './components/LateralMovementView';
import { LabConfigView } from './components/LabConfigView';
import { LabHealthView } from './components/LabHealthView';
import { MitreMatrixView } from './components/MitreMatrixView';
import {
  INTERFACE_TEMPLATES,
  DEMO_TARGETS,
  DEMO_FINDINGS,
  DEMO_ATTACK_NODES,
  DEMO_ATTACK_EDGES
} from './data/mockData';
import { InterfaceToneId } from './types';

export default function App() {
  const [selectedToneId, setSelectedToneId] = useState<InterfaceToneId>('kali-zsh-console');
  const [confirmedToneId, setConfirmedToneId] = useState<InterfaceToneId | null>('kali-zsh-console');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedPortTarget, setSelectedPortTarget] = useState<string>('192.168.56.10');
  const [isRoadmapOpen, setIsRoadmapOpen] = useState<boolean>(false);
  const [isTerminalMode, setIsTerminalMode] = useState<boolean>(false);
  const [findings, setFindings] = useState(DEMO_FINDINGS);
  const [targets, setTargets] = useState(DEMO_TARGETS);
  const [authorizedScope, setAuthorizedScope] = useState<string>('192.168.56.0/24');

  const reloadFindingsAndTargets = () => {
    fetch('/api/findings')
      .then(res => res.json())
      .then(data => { if (Array.isArray(data)) setFindings(data); })
      .catch(() => {});

    fetch('/api/targets')
      .then(res => res.json())
      .then(data => { if (Array.isArray(data)) setTargets(data); })
      .catch(() => {});

    fetch('/api/scope')
      .then(res => res.json())
      .then(data => { if (data && data.authorizedCidr) setAuthorizedScope(data.authorizedCidr); })
      .catch(() => {});
  };

  useEffect(() => {
    reloadFindingsAndTargets();
  }, []);

  const currentTemplate =
    INTERFACE_TEMPLATES.find((t) => t.id === selectedToneId) || INTERFACE_TEMPLATES[0];

  const handleConfirmTone = (toneId: InterfaceToneId) => {
    setConfirmedToneId(toneId);
  };

  return (
    <div className={`min-h-screen ${currentTemplate.palette.bgCanvas} ${currentTemplate.palette.textPrimary} flex flex-col font-sans transition-colors duration-200`}>
      {/* 1. Header & Authorized Lab Scope Bar */}
      <HeaderScopeBar
        template={currentTemplate}
        authorizedScope={authorizedScope}
        operator="sec-ops-01 | Hamza R."
        onOpenRoadmap={() => setIsRoadmapOpen(true)}
      />

      {/* 2. Interface Template & Tone Selector Bar (Primary User Selection Step) */}
      <ToneSelectorBar
        templates={INTERFACE_TEMPLATES}
        selectedToneId={selectedToneId}
        onSelectTone={(id) => setSelectedToneId(id)}
        confirmedToneId={confirmedToneId}
        onConfirmTone={handleConfirmTone}
        onToggleTerminalMode={() => setIsTerminalMode(!isTerminalMode)}
        isTerminalMode={isTerminalMode}
      />

      {/* 3. Main Application Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Nav reflecting all 18 modules */}
        <SidebarNav
          template={currentTemplate}
          activeTab={isTerminalMode ? 'execution' : activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            if (tab === 'execution') {
              setIsTerminalMode(true);
            } else {
              setIsTerminalMode(false);
            }
          }}
          targetCount={targets.length}
          findingsCount={findings.length}
          attackPathsCount={2}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Tone Selection Action Banner */}
          {confirmedToneId ? (
            <div className="p-3.5 rounded-lg bg-emerald-950/40 border border-emerald-500/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <div>
                  <span className="font-bold text-emerald-200 text-sm">
                    Tone Confirmed: {currentTemplate.name}
                  </span>
                  <p className="text-neutral-400 text-[11px]">
                    The interface design system has been configured. You can now proceed with subsequent development phases, or switch to another template anytime above.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsRoadmapOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-emerald-700 hover:bg-emerald-600 text-white font-bold cursor-pointer whitespace-nowrap self-start sm:self-auto"
              >
                <span>View Phase 1 Blueprint</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="p-3.5 rounded-lg bg-neutral-900 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center gap-2.5">
                <Layers className="w-5 h-5 text-red-400 flex-shrink-0" />
                <div>
                  <span className="font-bold text-neutral-100 text-sm">
                    Active Preview: {currentTemplate.name} ({currentTemplate.category})
                  </span>
                  <p className="text-neutral-400 text-[11px]">
                    Review the authentic programmer/CLI components below. Click any template card above to preview other terminals or SOC dashboards. When satisfied, click &quot;Select & Proceed with This Tone&quot;.
                  </p>
                </div>
              </div>
              <button
                onClick={() => handleConfirmTone(selectedToneId)}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-red-600 hover:bg-red-500 text-white font-bold cursor-pointer whitespace-nowrap self-start sm:self-auto shadow-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Select & Proceed with This Tone</span>
              </button>
            </div>
          )}

          {/* Dynamic Module Routing based on Sidebar Nav */}
          {activeTab === 'assessment' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-emerald-400" />
                  <span>ASSESSMENT SCOPE & BOUNDARY ENGINE</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <ScopeVerificationView
                template={currentTemplate}
                onScopeUpdated={(newCidr) => setAuthorizedScope(newCidr)}
              />
            </div>
          ) : activeTab === 'evidence' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <FileCheck2 className="w-4 h-4 text-red-400" />
                  <span>CRYPTOGRAPHIC EVIDENCE VAULT</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <EvidenceVaultView template={currentTemplate} />
            </div>
          ) : activeTab === 'reports' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>EXECUTIVE & TECHNICAL REPORTING</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <ExecutiveReportView template={currentTemplate} findings={DEMO_FINDINGS} />
            </div>
          ) : activeTab === 'activity' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-blue-400" />
                  <span>ACTIVITY & AUDIT TELEMETRY LOG</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <AuditLogView template={currentTemplate} />
            </div>
          ) : activeTab === 'targets' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Crosshair className="w-4 h-4 text-cyan-400" />
                  <span>AUTHORIZED TARGET ASSETS INVENTORY</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <TargetTableWidget template={currentTemplate} targets={DEMO_TARGETS} />
            </div>
          ) : activeTab === 'attackpaths' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Route className="w-4 h-4 text-red-400" />
                  <span>GRAPH-BASED ATTACK PATH ENGINE</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <AttackGraphPreview
                template={currentTemplate}
                nodes={DEMO_ATTACK_NODES}
                edges={DEMO_ATTACK_EDGES}
              />
            </div>
          ) : activeTab === 'findings' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>VERIFIED SECURITY FINDINGS CATALOG</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <FindingsSummaryWidget
                template={currentTemplate}
                findings={findings}
                onFindingUpdated={reloadFindingsAndTargets}
              />
            </div>
          ) : activeTab === 'discovery' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Radio className="w-4 h-4 text-emerald-400" />
                  <span>HOST DISCOVERY & SUBNET RECONNAISSANCE</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <HostDiscoveryView
                template={currentTemplate}
                onNavigateToPortScan={(ip) => {
                  setSelectedPortTarget(ip);
                  setActiveTab('enumeration');
                }}
              />
            </div>
          ) : activeTab === 'enumeration' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <ListTree className="w-4 h-4 text-cyan-400" />
                  <span>PORT & PROTOCOL SERVICE ENUMERATION</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <PortEnumerationView
                template={currentTemplate}
                defaultTarget={selectedPortTarget}
              />
            </div>
          ) : activeTab === 'activedirectory' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Network className="w-4 h-4 text-indigo-400" />
                  <span>ACTIVE DIRECTORY DOMAIN & LDAP HIERARCHY</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <ActiveDirectoryView
                template={currentTemplate}
                onSelectUserForRoast={() => {
                  setActiveTab('credentials');
                }}
              />
            </div>
          ) : activeTab === 'credentials' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-400" />
                  <span>CREDENTIAL HARVESTING & KERBEROASTING VALIDATION</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <CredentialsValidationView
                template={currentTemplate}
                onNavigateToVault={() => setActiveTab('evidence')}
              />
            </div>
          ) : activeTab === 'privilege' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-red-400" />
                  <span>PRIVILEGE ESCALATION & DCSYNC DIRECTORY REPLICATION</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <PrivilegeEscalationView
                template={currentTemplate}
                onNavigateToVault={() => setActiveTab('evidence')}
              />
            </div>
          ) : activeTab === 'lateral' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <GitFork className="w-4 h-4 text-purple-400" />
                  <span>LATERAL MOVEMENT & REMOTE PROTOCOL EXECUTION</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <LateralMovementView template={currentTemplate} />
            </div>
          ) : activeTab === 'labconfig' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-neutral-300" />
                  <span>LAB ENVIRONMENT SPECIFICATION & HARDENING BLUEPRINTS</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <LabConfigView template={currentTemplate} />
            </div>
          ) : activeTab === 'labhealth' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  <span>LAB RUNTIME &amp; TOOL INTEGRITY HEALTH CENTER</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <LabHealthView template={currentTemplate} />
            </div>
          ) : activeTab === 'attckmatrix' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-red-400" />
                  <span>MITRE ATT&amp;CK® ENTERPRISE MATRIX</span>
                </h2>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard
                </button>
              </div>
              <MitreMatrixView template={currentTemplate} />
            </div>
          ) : isTerminalMode || activeTab === 'execution' ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold font-mono text-neutral-100 flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-red-400" />
                    <span>DEDICATED PROGRAMMER / RED-TEAM CMD WORKBENCH</span>
                  </h2>
                  <p className="text-xs text-neutral-400 font-mono">
                    Full-featured interactive TUI console with ZSH shell prompt, Kerberos ticket hex inspector, LDAP object tree browser, and ASCII attack graphs.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setIsTerminalMode(false);
                    setActiveTab('dashboard');
                  }}
                  className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-mono text-neutral-200 border border-neutral-700 cursor-pointer"
                >
                  Return to Dashboard Overview
                </button>
              </div>

              <ProgrammerCmdWorkbench template={currentTemplate} />
            </div>
          ) : (
            <>
              {/* Assessment Executive Metric KPI Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {[
                  { label: 'Authorized Scope', val: authorizedScope, sub: 'Subnet Locked', icon: Lock, color: 'text-emerald-400' },
                  { label: 'Live Targets', val: '5 Hosts', sub: '1 Domain Controller', icon: Crosshair, color: 'text-neutral-200' },
                  { label: 'Critical Findings', val: '3 Critical', sub: '2 High Severity', icon: AlertTriangle, color: 'text-red-400' },
                  { label: 'Attack Paths', val: '2 Graph Paths', sub: 'Domain Admin Pivots', icon: Route, color: 'text-amber-400' },
                  { label: 'Evidence Artifacts', val: '12 Items', sub: 'SHA-256 Verified', icon: FileCheck2, color: 'text-blue-400' },
                  { label: 'Assessment Status', val: 'ACTIVE LAB', sub: 'Verification Signed', icon: ShieldAlert, color: 'text-emerald-400' },
                ].map((kpi, idx) => {
                  const Icon = kpi.icon;
                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-lg border ${currentTemplate.palette.border} ${currentTemplate.palette.bgCard} flex flex-col justify-between`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                          {kpi.label}
                        </span>
                        <Icon className={`w-3.5 h-3.5 ${kpi.color}`} />
                      </div>
                      <div>
                        <div className="text-sm font-bold font-mono text-neutral-100">{kpi.val}</div>
                        <div className="text-[10px] text-neutral-400 font-mono">{kpi.sub}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Core Interactive Attack Path Graph (BloodHound-Compatible) */}
              <AttackGraphPreview
                template={currentTemplate}
                nodes={DEMO_ATTACK_NODES}
                edges={DEMO_ATTACK_EDGES}
              />

              {/* Programmer / CMD Workbench in Dashboard */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-red-400" />
                    <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-neutral-200">
                      INTERACTIVE OFFENSIVE CMD & RECON WORKBENCH
                    </h3>
                  </div>
                  <span className="text-[11px] font-mono text-neutral-400">
                    Type commands or click quick presets (nmap, GetUserSPNs, secretsdump)
                  </span>
                </div>
                <ProgrammerCmdWorkbench template={currentTemplate} />
              </div>

              {/* Two-Column Layout: Target Inventory Table & Live Red-Team Terminal */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Target Inventory Table (7 Cols) */}
                <div className="lg:col-span-7 space-y-6">
                  <TargetTableWidget
                    template={currentTemplate}
                    targets={targets}
                  />
                  <FindingsSummaryWidget
                    template={currentTemplate}
                    findings={findings}
                    onFindingUpdated={reloadFindingsAndTargets}
                  />
                </div>

                {/* Red-Team Live Terminal & Recon Console (5 Cols) */}
                <div className="lg:col-span-5 space-y-6">
                  <TerminalWidget template={currentTemplate} />

                  {/* Lab Topology & Safety Verification Box */}
                  <div className={`rounded-lg border ${currentTemplate.palette.border} ${currentTemplate.palette.bgCard} p-4 text-xs font-mono space-y-3`}>
                    <div className="flex items-center gap-2 pb-2 border-b border-neutral-800">
                      <Server className="w-4 h-4 text-red-400" />
                      <span className="font-bold text-neutral-200">LAB TOPOLOGY STATUS</span>
                    </div>
                    <div className="space-y-2 text-[11px] text-neutral-300">
                      <div className="flex justify-between items-center py-1 border-b border-neutral-850">
                        <span className="text-neutral-400">Primary Domain Controller:</span>
                        <span className="font-bold text-neutral-100">DC01 (192.168.56.10)</span>
                      </div>
                      <div className="flex justify-between items-center py-1 border-b border-neutral-850">
                        <span className="text-neutral-400">Active Directory Domain:</span>
                        <span className="text-emerald-400 font-bold">adstrike.local</span>
                      </div>
                      <div className="flex justify-between items-center py-1 border-b border-neutral-850">
                        <span className="text-neutral-400">Kerberos Realm:</span>
                        <span className="text-neutral-200">ADSTRIKE.LOCAL</span>
                      </div>
                      <div className="flex justify-between items-center py-1">
                        <span className="text-neutral-400">Allowed Lab Subnet:</span>
                        <span className="font-bold text-emerald-300">192.168.56.0/24</span>
                      </div>
                    </div>
                    <div className="pt-2">
                      <div className="text-[10px] text-neutral-400 bg-neutral-950 p-2 rounded border border-neutral-900">
                        Host-only network bridge active. Any attempt to scan external routable IP ranges (e.g., 8.8.8.8, 1.1.1.1) is blocked by the Scope Enforcement Filter.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </main>
      </div>

      {/* 4. Phase Roadmap & Master Specification Modal */}
      <PhaseRoadmapModal
        isOpen={isRoadmapOpen}
        onClose={() => setIsRoadmapOpen(false)}
        template={currentTemplate}
      />
    </div>
  );
}

