export type InterfaceToneId = 
  | 'kali-zsh-console'
  | 'cobalt-beacon-cmd'
  | 'retro-amber-crt'
  | 'bloodhound-cypher-cli'
  | 'tactical-red' 
  | 'matrix-terminal' 
  | 'modern-soc' 
  | 'precision-indigo';

export interface InterfaceTemplate {
  id: InterfaceToneId;
  name: string;
  tagline: string;
  category: string;
  description: string;
  palette: {
    bgCanvas: string;
    bgPanel: string;
    bgCard: string;
    border: string;
    borderAccent: string;
    textPrimary: string;
    textSecondary: string;
    accentPrimary: string;
    accentGlow: string;
    accentSecondary: string;
    badgeCritical: string;
    badgeHigh: string;
    badgeMedium: string;
    badgeLow: string;
  };
  typography: {
    displayFont: string;
    bodyFont: string;
    monoFont: string;
  };
  recommendedFor: string;
}

export interface LabTarget {
  id: string;
  ip: string;
  hostname: string;
  os: string;
  role: 'Domain Controller' | 'Workstation' | 'Member Server' | 'Linux Host' | 'Assessment Machine';
  domain: string;
  openPorts: number[];
  risk: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'ONLINE' | 'SCANNING' | 'ISOLATED';
  lastSeen: string;
  vulnerabilitiesCount: number;
}

export type ExecutionMode = 'REAL' | 'SIMULATED';

export type FindingLifecycle = 'OPEN' | 'VALIDATED' | 'REMEDIATING' | 'REMEDIATED' | 'ACCEPTED' | 'FALSE_POSITIVE';

export interface FindingItem {
  id: string;
  findingId: string;
  title: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  affectedAsset: string;
  mitreId: string;
  mitreTactic: string;
  description: string;
  impact?: string;
  likelihood?: 'HIGH' | 'MEDIUM' | 'LOW';
  cvssScore?: number;
  status: FindingLifecycle;
  remediation?: string;
  references?: string[];
  linkedEvidenceIds?: string[];
  executionMode?: ExecutionMode;
}

export interface AttackNode {
  id: string;
  label: string;
  type: 'user' | 'workstation' | 'server' | 'dc' | 'group' | 'ticket';
  compromised: boolean;
  roleDescription: string;
  x: number;
  y: number;
  ip?: string;
  privilegeLevel?: 'Standard' | 'Elevated' | 'DomainAdmin';
}

export interface AttackEdge {
  from: string;
  to: string;
  relationship: string;
  technique: string;
  risk: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  mitreId?: string;
  description?: string;
}

export interface EvidenceArtifact {
  id: string;
  assessmentId?: string;
  mitreId: string;
  technique: string;
  targetHost: string;
  sourceTool: string;
  timestamp: string;
  sha256: string;
  operator: string;
  payloadType: 'hash' | 'ticket' | 'ldap_dump' | 'nmap_xml' | 'ntds_dit' | 'smb_probe' | 'log';
  sizeBytes?: number;
  mimeType?: string;
  rawPreview: string;
  verified: boolean;
  executionMode: ExecutionMode;
  associatedFindingId?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  operator: string;
  action: string;
  target: string;
  scopeStatus: 'IN_SCOPE_ALLOWED' | 'OUT_OF_SCOPE_REJECTED';
  executionMode?: ExecutionMode;
  details: string;
}

export interface LabScopeConfig {
  assessmentName: string;
  authorizedCidr: string;
  subnetMask: string;
  networkAddress: string;
  broadcastAddress: string;
  allowedHosts: string[];
  excludedHosts?: string[];
  operatorSignature: string;
  strictBlocking: boolean;
  rulesOfEngagement: string[];
}

export interface ADUserAccount {
  sAMAccountName: string;
  displayName: string;
  distinguishedName: string;
  servicePrincipalNames: string[];
  userAccountControl: number;
  uacFlags: string[];
  adminCount: boolean;
  passwordLastSet: string;
  kerberoastable: boolean;
  asrepRoastable: boolean;
  unconstrainedDelegation: boolean;
  memberOf: string[];
}

export interface PortScanItem {
  port: number;
  protocol: 'tcp' | 'udp';
  state: 'open' | 'filtered' | 'closed';
  service: string;
  version: string;
  smbSigning?: 'REQUIRED' | 'DISABLED' | 'NOT_APPLICABLE' | 'UNKNOWN';
  detectionMethod?: 'SOCKET_CONNECT' | 'NMAP_SYN' | 'BANNER_GRAB' | 'SIMULATED';
}

export interface DiscoveredHost {
  ip: string;
  hostname: string;
  mac: string;
  vendor: string;
  latency: string;
  status: 'ONLINE' | 'FILTERED' | 'OFFLINE';
  adRole: string;
  discoveryMethod?: 'TCP_SOCKET' | 'ARP' | 'ICMP' | 'SIMULATED';
  executionMode: ExecutionMode;
}

export interface ToolHealthItem {
  id: string;
  name: string;
  command: string;
  installed: boolean;
  version?: string;
  status: 'READY' | 'NOT_INSTALLED' | 'ERROR';
  description: string;
}

export interface LabHealthReport {
  timestamp: string;
  tools: ToolHealthItem[];
  networkInterfaces: string[];
  activeAssessmentScope: string;
  readyForAssessment: boolean;
}

export interface LabHealthStatus {
  timestamp: string;
  platform: string;
  overallStatus: 'HEALTHY' | 'DEGRADED';
  tools: {
    name: string;
    command: string;
    installed: boolean;
    version?: string;
    notes?: string;
  }[];
  scope: LabScopeConfig;
  activeTasksCount: number;
}

export interface LdapConfig {
  domain: string;
  dcHost: string;
  port: number;
  useTls: boolean;
  bindUser: string;
  baseDn: string;
}

export interface ExecutionTask {
  id: string;
  module: string;
  tool: string;
  target: string;
  executionMode: ExecutionMode;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  startedAt: string;
  completedAt?: string;
  durationMs?: number;
  exitCode?: number;
  outputLines: string[];
}
