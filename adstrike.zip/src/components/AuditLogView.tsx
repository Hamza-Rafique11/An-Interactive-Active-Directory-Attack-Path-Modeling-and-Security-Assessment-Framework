import React, { useState, useEffect } from 'react';
import {
  History,
  ShieldCheck,
  ShieldAlert,
  Terminal,
  RefreshCw,
  Search,
  Filter
} from 'lucide-react';
import { InterfaceTemplate, AuditLogEntry } from '../types';

interface AuditLogViewProps {
  template: InterfaceTemplate;
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ template }) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const fetchLogs = () => {
    setLoading(true);
    fetch('/api/audit')
      .then((res) => res.json())
      .then((data) => setLogs(data))
      .catch((err) => console.error('Error fetching audit logs:', err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const filteredLogs = logs.filter((log) => {
    const q = searchTerm.toLowerCase();
    return (
      log.action.toLowerCase().includes(q) ||
      log.target.toLowerCase().includes(q) ||
      log.details.toLowerCase().includes(q) ||
      log.operator.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Header Bar */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-neutral-900 text-neutral-200 border border-neutral-700">
            <History className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100">
                CHRONOLOGICAL AUDIT &amp; TELEMETRY LEDGER
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
                {logs.length} EVENTS RECORDED
              </span>
            </div>
            <p className="text-neutral-400 text-xs mt-0.5">
              Immutable record of all commands, scope safety evaluations, and operator actions during this engagement.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchLogs}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-neutral-850 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Filter audit log by command, action, target IP, or operator..."
          className="w-full bg-neutral-950 border border-neutral-800 rounded-lg pl-9 pr-3 py-2 text-xs text-neutral-200 font-mono focus:outline-none focus:border-neutral-600"
        />
      </div>

      {/* Audit Log Table */}
      <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgCard} overflow-hidden shadow-xl`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-800 bg-neutral-950/80 text-[10px] uppercase font-bold text-neutral-400">
                <th className="py-2.5 px-3">Timestamp (UTC)</th>
                <th className="py-2.5 px-3">Operator</th>
                <th className="py-2.5 px-3">Action Type</th>
                <th className="py-2.5 px-3">Target</th>
                <th className="py-2.5 px-3">Scope Guard Status</th>
                <th className="py-2.5 px-3">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-850">
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log) => {
                  const isBlocked = log.scopeStatus === 'OUT_OF_SCOPE_REJECTED';
                  return (
                    <tr
                      key={log.id}
                      className={`hover:bg-neutral-900/40 transition-colors ${
                        isBlocked ? 'bg-red-950/20' : ''
                      }`}
                    >
                      <td className="py-2 px-3 text-neutral-400 whitespace-nowrap">
                        {log.timestamp}
                      </td>
                      <td className="py-2 px-3 text-neutral-300 font-bold whitespace-nowrap">
                        {log.operator}
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-neutral-900 border border-neutral-750 text-neutral-200">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-cyan-300 font-bold whitespace-nowrap">
                        {log.target}
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            isBlocked
                              ? 'bg-red-950 text-red-400 border border-red-800'
                              : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          }`}
                        >
                          {isBlocked ? (
                            <>
                              <ShieldAlert className="w-3 h-3" />
                              <span>BLOCKED</span>
                            </>
                          ) : (
                            <>
                              <ShieldCheck className="w-3 h-3" />
                              <span>IN-SCOPE</span>
                            </>
                          )}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-neutral-300 text-xs">
                        {log.details}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-neutral-400">
                    No matching audit records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
