import React from 'react';
import {
  LayoutDashboard,
  FolderKanban,
  Crosshair,
  Radio,
  ListTree,
  Network,
  KeyRound,
  TrendingUp,
  GitFork,
  Route,
  FileCheck2,
  AlertTriangle,
  FileText,
  Sliders,
  Settings,
  History,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface SidebarNavProps {
  template: InterfaceTemplate;
  activeTab: string;
  onTabChange: (tabId: string) => void;
  targetCount: number;
  findingsCount: number;
  attackPathsCount: number;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  template,
  activeTab,
  onTabChange,
  targetCount,
  findingsCount,
  attackPathsCount,
}) => {
  const navSections = [
    {
      group: 'ASSESSMENT CORE',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'execution', label: 'Kali ZSH & TUI Terminal', icon: Zap, badge: 'PROMPT' },
        { id: 'assessment', label: 'Assessment Scope', icon: FolderKanban, badge: 'LOCKED' },
        { id: 'targets', label: 'Target Assets', icon: Crosshair, badge: targetCount.toString() },
      ]
    },
    {
      group: 'RECON & ENUMERATION',
      items: [
        { id: 'discovery', label: 'Host Discovery', icon: Radio },
        { id: 'enumeration', label: 'Port & Services', icon: ListTree },
        { id: 'activedirectory', label: 'Active Directory', icon: Network, highlight: true },
      ]
    },
    {
      group: 'OFFENSIVE VALIDATION',
      items: [
        { id: 'credentials', label: 'Credentials & SPNs', icon: KeyRound },
        { id: 'privilege', label: 'Privilege Escalation', icon: TrendingUp },
        { id: 'lateral', label: 'Lateral Movement', icon: GitFork },
        { id: 'attackpaths', label: 'Attack Paths', icon: Route, badge: attackPathsCount.toString() },
      ]
    },
    {
      group: 'AUDIT & REPORTING',
      items: [
        { id: 'attckmatrix', label: 'MITRE ATT&CK Matrix', icon: ShieldCheck, badge: '11 MAP' },
        { id: 'evidence', label: 'Evidence Vault', icon: FileCheck2 },
        { id: 'findings', label: 'Security Findings', icon: AlertTriangle, badge: findingsCount.toString() },
        { id: 'reports', label: 'Executive Reports', icon: FileText },
      ]
    },
    {
      group: 'SYSTEM & LAB',
      items: [
        { id: 'labhealth', label: 'Lab Health Center', icon: Zap, badge: 'DIAG' },
        { id: 'labconfig', label: 'Lab Configuration', icon: Sliders },
        { id: 'activity', label: 'Activity & Audit Log', icon: History },
        { id: 'settings', label: 'Settings', icon: Settings },
      ]
    }
  ];

  return (
    <aside className={`w-64 border-r ${template.palette.border} ${template.palette.bgPanel} flex flex-col justify-between h-[calc(100vh-130px)] overflow-y-auto text-xs`}>
      <div className="p-3 space-y-4">
        {navSections.map((section) => (
          <div key={section.group}>
            <div className="text-[10px] font-mono font-bold tracking-wider text-neutral-400 px-2 py-1 uppercase">
              {section.group}
            </div>

            <nav className="space-y-0.5 mt-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => onTabChange(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-left transition-all font-mono cursor-pointer ${
                      isActive
                        ? `${template.palette.bgCard} ${template.palette.textPrimary} font-bold border-l-2 ${template.palette.borderAccent}`
                        : `text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/50`
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className={`w-3.5 h-3.5 ${isActive ? template.palette.accentSecondary : 'text-neutral-400'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-semibold ${
                        item.badge === 'LOCKED'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/50'
                          : 'bg-neutral-800 text-neutral-300 border border-neutral-700'
                      }`}>
                        {item.badge}
                      </span>
                    )}

                    {item.highlight && !item.badge && (
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Lab Safety Status Footnote */}
      <div className="p-3 border-t border-neutral-800/80 bg-neutral-950/40">
        <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
          <span>Restricted to Authorized Lab Only</span>
        </div>
        <div className="mt-1 text-[10px] font-mono text-neutral-400">
          No external traffic routed.
        </div>
      </div>
    </aside>
  );
};
