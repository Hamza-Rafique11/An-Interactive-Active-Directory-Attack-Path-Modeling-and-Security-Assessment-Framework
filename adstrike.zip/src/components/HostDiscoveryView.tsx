import React, { useState, useEffect } from 'react';
import {
  Radio,
  RefreshCw,
  CheckCircle2,
  ShieldAlert,
  ShieldCheck,
  Laptop,
  Server,
  Network,
  ArrowRight,
  AlertTriangle
} from 'lucide-react';
import { InterfaceTemplate, DiscoveredHost, ExecutionMode } from '../types';

interface HostDiscoveryViewProps {
  template: InterfaceTemplate;
  onNavigateToPortScan?: (ip: string) => void;
}

export const HostDiscoveryView: React.FC<HostDiscoveryViewProps> = ({
  template,
  onNavigateToPortScan,
}) => {
  const [hosts, setHosts] = useState<DiscoveredHost[]>([]);
  const [loading, setLoading] = useState(false);
  const [scanType, setScanType] = useState<'arp' | 'icmp' | 'tcp_syn'>('arp');
  const [subnet, setSubnet] = useState('192.168.56.0/24');
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('AUTO');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [scopeWarning, setScopeWarning] = useState<string | null>(null);
  const [lastScanMode, setLastScanMode] = useState<string | null>(null);

  const fetchHosts = async () => {
    try {
      const res = await fetch('/api/discovery/hosts');
      if (res.ok) {
        const data = await res.json();
        setHosts(data);
      }
    } catch {
      // Fallback
    }
  };

  useEffect(() => {
    fetchHosts();
  }, []);

  const runDiscoveryScan = async () => {
    setLoading(true);
    setScopeWarning(null);
    setStatusMessage(`Initiating ${scanType.toUpperCase()} discovery sweep on ${subnet}...`);

    try {
      const res = await fetch('/api/discovery/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subnet, scanType, executionMode })
      });

      const data = await res.json();

      if (res.status === 403) {
        setScopeWarning(data.message || data.error || 'TARGET OUT OF AUTHORIZED SCOPE');
        setStatusMessage(null);
      } else if (res.ok) {
        setHosts(data.hosts || []);
        setLastScanMode(data.executionMode || 'SIMULATED');
        setStatusMessage(
          `Discovery sweep complete: ${data.responsiveHosts} live hosts responding on ${data.subnet} (${data.durationMs}ms). Mode: ${data.executionMode}`
        );
      } else {
        setStatusMessage(`Error: ${data.error || 'Failed to execute discovery'}`);
      }
    } catch (err: any) {
      setStatusMessage(`Sweep failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Scope Warning Banner if out-of-scope entered */}
      {scopeWarning && (
        <div className="p-3.5 rounded-xl bg-red-950/90 border border-red-800 text-red-300 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <span className="font-bold block">SCOPE GUARD VIOLATION PREVENTED:</span>
              <span className="text-[11px] text-red-300">{scopeWarning}</span>
            </div>
          </div>
          <button
            onClick={() => {
              setSubnet('192.168.56.0/24');
              setScopeWarning(null);
            }}
            className="px-2.5 py-1 rounded bg-red-900/80 hover:bg-red-800 text-white text-[10px] font-bold border border-red-700 cursor-pointer"
          >
            Reset to Lab Subnet
          </button>
        </div>
      )}

      {/* Control Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-3`}>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded bg-emerald-950/70 border border-emerald-800/60 text-emerald-400">
              <Radio className={`w-5 h-5 ${loading ? 'animate-pulse text-emerald-300' : ''}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
                  ARP / ICMP / TCP LIVE HOST DISCOVERY ENGINE
                </h3>
                {lastScanMode && (
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    lastScanMode === 'REAL'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                      : 'bg-amber-950 text-amber-300 border border-amber-700'
                  }`}>
                    {lastScanMode === 'REAL' ? '🟢 REAL LAB PROBE' : '🟡 DEMO / SIMULATION'}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-neutral-400">
                L2 ARP &amp; L4 TCP Syn sweeps strictly bounded to authorized lab subnet (192.168.56.0/24)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Execution Mode Selector */}
            <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-700 rounded px-2 py-1">
              <span className="text-[10px] text-neutral-400">Mode:</span>
              <select
                value={executionMode}
                onChange={(e) => setExecutionMode(e.target.value as ExecutionMode)}
                className="bg-transparent text-emerald-400 font-bold outline-none cursor-pointer text-xs"
              >
                <option value="AUTO">AUTO (Real Lab + Blueprint Fallback)</option>
                <option value="REAL">REAL ONLY (Enforce Active Probe)</option>
                <option value="SIMULATED">SIMULATED (Offline Lab Blueprint)</option>
              </select>
            </div>

            <select
              value={scanType}
              onChange={(e) => setScanType(e.target.value as any)}
              className="bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-neutral-200 outline-none"
            >
              <option value="arp">ARP Sweep (Fast L2)</option>
              <option value="icmp">ICMP Echo Request</option>
              <option value="tcp_syn">TCP SYN Sweep (445/135/88)</option>
            </select>

            <button
              onClick={runDiscoveryScan}
              disabled={loading}
              className="px-4 py-1.5 rounded font-bold bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'SWEEPING...' : 'RUN HOST SWEEP'}</span>
            </button>
          </div>
        </div>

        {/* Subnet scope indicator & input */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-800/80 text-[11px]">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Target Subnet / IP:</span>
            <input
              type="text"
              value={subnet}
              onChange={(e) => setSubnet(e.target.value)}
              className="bg-neutral-900 border border-neutral-700 rounded px-2 py-0.5 text-emerald-400 font-mono font-bold w-40 outline-none"
            />
            <span className="text-neutral-400">(Lab Host-Only Virtual Adapter)</span>
          </div>

          {statusMessage && (
            <div className="text-emerald-400 text-[11px] font-bold truncate max-w-md">
              {statusMessage}
            </div>
          )}
        </div>
      </div>

      {/* Discovered Hosts Table */}
      <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} overflow-hidden shadow-xl`}>
        <div className="p-3 bg-neutral-900/80 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Network className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-neutral-200 text-xs">
              LIVE IDENTIFIED HOSTS ({hosts.length})
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-neutral-400">
              Scope Boundary: 192.168.56.0/24
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="bg-neutral-950/90 text-neutral-400 border-b border-neutral-800">
                <th className="py-2.5 px-3">IP ADDRESS</th>
                <th className="py-2.5 px-3">HOSTNAME / FQDN</th>
                <th className="py-2.5 px-3">MAC &amp; OUI VENDOR</th>
                <th className="py-2.5 px-3">DETECTED AD ROLE</th>
                <th className="py-2.5 px-3">LATENCY</th>
                <th className="py-2.5 px-3">SOURCE MODE</th>
                <th className="py-2.5 px-3 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-850">
              {hosts.map((host) => (
                <tr key={host.ip} className="hover:bg-neutral-900/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-emerald-400">
                    {host.ip}
                  </td>
                  <td className="py-2.5 px-3 text-neutral-200 font-semibold">
                    {host.hostname}
                  </td>
                  <td className="py-2.5 px-3 text-neutral-400">
                    <span className="text-neutral-300">{host.mac}</span>
                    <span className="text-neutral-400 block text-[10px]">{host.vendor}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      host.adRole.includes('Domain Controller')
                        ? 'bg-red-950/80 text-red-300 border border-red-800/60'
                        : host.adRole.includes('SQL')
                        ? 'bg-amber-950/80 text-amber-300 border border-amber-800/60'
                        : 'bg-neutral-800 text-neutral-300'
                    }`}>
                      {host.adRole}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-neutral-300 font-mono">
                    {host.latency}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-300">
                      {host.probeMethod ? (
                        <>
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span>{host.probeMethod}</span>
                        </>
                      ) : (
                        <>
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                          <span>LAB BLUEPRINT</span>
                        </>
                      )}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => onNavigateToPortScan?.(host.ip)}
                      className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white border border-neutral-700 inline-flex items-center gap-1 cursor-pointer transition-colors text-[10px]"
                    >
                      <span>Port Scan</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
