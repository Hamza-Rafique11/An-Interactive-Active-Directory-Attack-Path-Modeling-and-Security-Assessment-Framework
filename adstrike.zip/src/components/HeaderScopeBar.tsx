import React from 'react';
import { ShieldCheck, ShieldAlert, Lock, UserCheck, Terminal, Cpu } from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface HeaderScopeBarProps {
  template: InterfaceTemplate;
  authorizedScope: string;
  operator: string;
  onOpenRoadmap: () => void;
}

export const HeaderScopeBar: React.FC<HeaderScopeBarProps> = ({
  template,
  authorizedScope,
  operator,
  onOpenRoadmap
}) => {
  return (
    <header className={`w-full border-b ${template.palette.border} ${template.palette.bgPanel} px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs`}>
      {/* Brand & Mode Tag */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center w-8 h-8 rounded bg-red-950/60 border border-red-500/50 text-red-400">
            <ShieldAlert className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-wider text-sm text-neutral-100 font-mono">
                AD<span className="text-red-500">STRIKE</span>
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-red-900/40 text-red-300 border border-red-800/60 font-semibold tracking-wide">
                v1.0.0-LAB
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 font-mono hidden sm:block">
              Active Directory Red-Team Assessment Platform
            </p>
          </div>
        </div>

        {/* Authorized Scope Guard Badge */}
        <div className="flex items-center gap-2 pl-3 border-l border-neutral-800">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-950/40 border border-emerald-600/50 text-emerald-400 font-mono text-[11px]">
            <Lock className="w-3 h-3 text-emerald-400" />
            <span className="font-bold">SCOPE LOCKED:</span>
            <span className="text-emerald-200 underline font-semibold">{authorizedScope}</span>
          </div>
          <span className="hidden lg:inline-flex items-center gap-1 text-neutral-400 text-[11px] font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Strict Out-of-Scope Blocking Active
          </span>
        </div>
      </div>

      {/* Operator & System Status */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Operator Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-neutral-300 font-mono text-[11px]">
          <UserCheck className="w-3 h-3 text-neutral-400" />
          <span className="text-neutral-400">Operator:</span>
          <span className="text-neutral-100 font-semibold">{operator}</span>
        </div>

        {/* Live Lab Engine Status */}
        <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded bg-neutral-900/90 border border-neutral-800 font-mono text-[11px]">
          <div className="flex items-center gap-1 text-neutral-300">
            <Cpu className="w-3 h-3 text-neutral-400" />
            <span>Engines:</span>
          </div>
          <span className="flex items-center gap-1 text-emerald-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
            Nmap, LDAP, Kerberos Ready
          </span>
        </div>

        {/* Specification & Architecture Roadmap Button */}
        <button
          onClick={onOpenRoadmap}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded font-mono text-xs font-medium border border-neutral-700 bg-neutral-800/80 hover:bg-neutral-700 text-neutral-200 transition-colors shadow-sm cursor-pointer"
          title="View Master Architectural Blueprint and 10-Phase Roadmap"
        >
          <Terminal className="w-3.5 h-3.5 text-red-400" />
          <span>Spec & Phases</span>
        </button>
      </div>
    </header>
  );
};
