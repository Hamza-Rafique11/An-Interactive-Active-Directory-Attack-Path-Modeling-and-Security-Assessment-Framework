import React, { useState } from 'react';
import {
  KeyRound,
  ShieldAlert,
  Zap,
  Lock,
  Terminal,
  CheckCircle2,
  Copy,
  ArrowRight,
  Database,
  Eye,
  EyeOff,
  AlertTriangle
} from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface CredentialsValidationViewProps {
  template: InterfaceTemplate;
  onNavigateToVault?: () => void;
}

export const CredentialsValidationView: React.FC<CredentialsValidationViewProps> = ({
  template,
  onNavigateToVault,
}) => {
  const [kerberoastResult, setKerberoastResult] = useState<any>(null);
  const [kerberoastLoading, setKerberoastLoading] = useState(false);
  const [kerberoastCracked, setKerberoastCracked] = useState(false);
  const [showKerbHash, setShowKerbHash] = useState(false);

  const [asrepResult, setAsrepResult] = useState<any>(null);
  const [asrepLoading, setAsrepLoading] = useState(false);
  const [asrepCracked, setAsrepCracked] = useState(false);
  const [showAsrepHash, setShowAsrepHash] = useState(false);

  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleKerberoast = async () => {
    setKerberoastLoading(true);
    try {
      const res = await fetch('/api/attack/kerberoast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ account: 'svc_mssql' })
      });
      if (res.ok) {
        const data = await res.json();
        setKerberoastResult(data);
      }
    } catch {
      // Error
    } finally {
      setKerberoastLoading(false);
    }
  };

  const handleAsrepRoast = async () => {
    setAsrepLoading(true);
    try {
      const res = await fetch('/api/attack/asreproast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ account: 'backup_operator' })
      });
      if (res.ok) {
        const data = await res.json();
        setAsrepResult(data);
      }
    } catch {
      // Error
    } finally {
      setKerberoastLoading(false);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Header Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} flex flex-col md:flex-row md:items-center justify-between gap-3`}>
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-amber-950/80 border border-amber-800/60 text-amber-400">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
                KERBEROS TICKET EXTRACTION &amp; OFFENSIVE VALIDATION
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700">
                🟡 LAB SIMULATION / VALIDATED VECTORS
              </span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Extraction of Kerberoastable TGS and AS-REP tickets mapped to cryptographic SHA-256 evidence
            </p>
          </div>
        </div>

        <button
          onClick={onNavigateToVault}
          className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 flex items-center gap-2 cursor-pointer transition-colors"
        >
          <Database className="w-4 h-4 text-red-400" />
          <span>Open Evidence Vault</span>
          <ArrowRight className="w-3.5 h-3.5 text-neutral-400" />
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Kerberoasting Card */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-4 shadow-xl`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/60 font-bold text-[10px]">
                MITRE T1558.003
              </span>
              <h4 className="font-bold text-neutral-200 text-xs">
                KERBEROASTING (GetUserSPNs.py)
              </h4>
            </div>
            <span className="text-[10px] text-neutral-400">
              SPN: MSSQLSvc/WIN-SRV-01.adstrike.local:1433
            </span>
          </div>

          <p className="text-[11px] text-neutral-400 leading-relaxed">
            Requests a Kerberos Service Ticket (TGS) for user account <strong className="text-neutral-200">svc_mssql</strong> using legacy RC4-HMAC encryption. The ticket is encrypted with the service account password hash and can be brute-forced offline.
          </p>

          <div className="p-3 rounded bg-neutral-950 border border-neutral-850 space-y-2 text-[10px]">
            <div className="flex justify-between text-neutral-400">
              <span>Target Account:</span>
              <span className="text-neutral-200 font-bold">svc_mssql (ADSTRIKE\svc_mssql)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Cipher Mode:</span>
              <span className="text-amber-400 font-bold">RC4-HMAC (etype 23 - Vulnerable)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Hashcat Mode:</span>
              <span className="text-neutral-200">13100 (Kerberos 5 TGS-REP etype 23)</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleKerberoast}
              disabled={kerberoastLoading}
              className="flex-1 py-2 rounded bg-amber-700 hover:bg-amber-600 disabled:opacity-50 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-colors"
            >
              <Zap className={`w-4 h-4 ${kerberoastLoading ? 'animate-spin' : ''}`} />
              <span>{kerberoastLoading ? 'REQUESTING TGS TICKET...' : 'REQUEST TGS TICKET (IMPACKET)'}</span>
            </button>
          </div>

          {/* Results Output */}
          {kerberoastResult && (
            <div className="p-3 rounded-lg bg-neutral-950 border border-amber-900/40 space-y-2.5">
              <div className="flex items-center justify-between text-[10px] text-amber-400 font-bold">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>TGS TICKET HARVESTED // SHA-256 RECORDED</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowKerbHash(!showKerbHash)}
                    className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                  >
                    {showKerbHash ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showKerbHash ? 'Mask' : 'Reveal'}</span>
                  </button>
                  <button
                    onClick={() => copyToClipboard(kerberoastResult.extractedHash, 'kerberoast')}
                    className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedText === 'kerberoast' ? 'COPIED!' : 'COPY HASH'}</span>
                  </button>
                </div>
              </div>

              <div className="p-2 rounded bg-black/70 border border-neutral-800 text-[10px] text-neutral-300 font-mono break-all max-h-20 overflow-y-auto">
                {showKerbHash
                  ? kerberoastResult.extractedHash
                  : kerberoastResult.extractedHash.slice(0, 32) + '... [MASKED FOR OPSEC SAFEGUARD]'}
              </div>

              {/* Offline Crack Simulator */}
              <div className="pt-2 border-t border-neutral-850 flex items-center justify-between">
                <div>
                  <span className="text-neutral-400 text-[10px]">Dictionary Crack:</span>
                  {kerberoastCracked ? (
                    <span className="ml-2 px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 font-bold border border-emerald-800/60">
                      CLEARTEXT: Winter2026!
                    </span>
                  ) : (
                    <span className="ml-2 text-neutral-400">Wordlist (rockyou.txt)</span>
                  )}
                </div>

                {!kerberoastCracked && (
                  <button
                    onClick={() => setKerberoastCracked(true)}
                    className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[10px] font-bold cursor-pointer"
                  >
                    Simulate Hashcat Crack
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* AS-REP Roasting Card */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-4 shadow-xl`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/60 font-bold text-[10px]">
                MITRE T1558.004
              </span>
              <h4 className="font-bold text-neutral-200 text-xs">
                AS-REP ROASTING (GetNPUsers.py)
              </h4>
            </div>
            <span className="text-[10px] text-neutral-400">
              Account: backup_operator
            </span>
          </div>

          <p className="text-[11px] text-neutral-400 leading-relaxed">
            Requests an Authentication Service (AS) ticket without providing pre-authentication credentials for <strong className="text-neutral-200">backup_operator</strong> (which has the <code className="text-red-300">DONT_REQ_PREAUTH</code> flag set).
          </p>

          <div className="p-3 rounded bg-neutral-950 border border-neutral-850 space-y-2 text-[10px]">
            <div className="flex justify-between text-neutral-400">
              <span>Target Account:</span>
              <span className="text-neutral-200 font-bold">backup_operator (ADSTRIKE)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Vulnerability Flag:</span>
              <span className="text-red-400 font-bold">DONT_REQ_PREAUTH (UAC 0x400000)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Hashcat Mode:</span>
              <span className="text-neutral-200">18200 (Kerberos 5 AS-REP etype 23)</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAsrepRoast}
              disabled={asrepLoading}
              className="flex-1 py-2 rounded bg-red-800 hover:bg-red-700 disabled:opacity-50 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-colors"
            >
              <Zap className={`w-4 h-4 ${asrepLoading ? 'animate-spin' : ''}`} />
              <span>{asrepLoading ? 'HARVESTING AS-REP...' : 'HARVEST AS-REP (GETNPUSERS)'}</span>
            </button>
          </div>

          {/* Results Output */}
          {asrepResult && (
            <div className="p-3 rounded-lg bg-neutral-950 border border-red-900/40 space-y-2.5">
              <div className="flex items-center justify-between text-[10px] text-red-400 font-bold">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>AS-REP HASH HARVESTED // SHA-256 RECORDED</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowAsrepHash(!showAsrepHash)}
                    className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                  >
                    {showAsrepHash ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showAsrepHash ? 'Mask' : 'Reveal'}</span>
                  </button>
                  <button
                    onClick={() => copyToClipboard(asrepResult.extractedHash, 'asrep')}
                    className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedText === 'asrep' ? 'COPIED!' : 'COPY HASH'}</span>
                  </button>
                </div>
              </div>

              <div className="p-2 rounded bg-black/70 border border-neutral-800 text-[10px] text-neutral-300 font-mono break-all max-h-20 overflow-y-auto">
                {showAsrepHash
                  ? asrepResult.extractedHash
                  : asrepResult.extractedHash.slice(0, 32) + '... [MASKED FOR OPSEC SAFEGUARD]'}
              </div>

              {/* Offline Crack Simulator */}
              <div className="pt-2 border-t border-neutral-850 flex items-center justify-between">
                <div>
                  <span className="text-neutral-400 text-[10px]">Dictionary Crack:</span>
                  {asrepCracked ? (
                    <span className="ml-2 px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 font-bold border border-emerald-800/60">
                      CLEARTEXT: Backup123$
                    </span>
                  ) : (
                    <span className="ml-2 text-neutral-400">Wordlist (rockyou.txt)</span>
                  )}
                </div>

                {!asrepCracked && (
                  <button
                    onClick={() => setAsrepCracked(true)}
                    className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[10px] font-bold cursor-pointer"
                  >
                    Simulate Hashcat Crack
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
