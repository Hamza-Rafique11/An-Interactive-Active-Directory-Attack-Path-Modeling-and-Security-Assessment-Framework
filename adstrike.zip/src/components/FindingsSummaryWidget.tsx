import React, { useState } from 'react';
import {
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  Tag,
  Filter,
  Check,
  ExternalLink,
  Edit2
} from 'lucide-react';
import { InterfaceTemplate, FindingItem, FindingLifecycle } from '../types';

interface FindingsSummaryWidgetProps {
  template: InterfaceTemplate;
  findings: FindingItem[];
  onFindingUpdated?: () => void;
}

export const FindingsSummaryWidget: React.FC<FindingsSummaryWidgetProps> = ({
  template,
  findings: initialFindings,
  onFindingUpdated,
}) => {
  const [findings, setFindings] = useState<FindingItem[]>(initialFindings);
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [selectedFinding, setSelectedFinding] = useState<FindingItem | null>(null);

  // Sync if props update
  React.useEffect(() => {
    setFindings(initialFindings);
  }, [initialFindings]);

  const updateFindingStatus = async (id: string, newStatus: FindingLifecycle) => {
    try {
      const res = await fetch(`/api/findings/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setFindings(prev =>
          prev.map(f => (f.id === id ? { ...f, status: newStatus } : f))
        );
        if (selectedFinding?.id === id) {
          setSelectedFinding(prev => prev ? { ...prev, status: newStatus } : null);
        }
        onFindingUpdated?.();
      }
    } catch (err) {
      console.error('Failed to update finding status:', err);
    }
  };

  const filtered = findings.filter(f => {
    if (filterSeverity === 'ALL') return true;
    return f.severity === filterSeverity;
  });

  return (
    <div className={`rounded-lg border ${template.palette.border} ${template.palette.bgCard} p-4 text-xs font-mono space-y-3`}>
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-800/80">
        <div className="flex items-center gap-2">
          <AlertTriangle className={`w-4 h-4 ${template.palette.accentSecondary}`} />
          <span className="font-bold text-sm text-neutral-100 font-mono">
            SECURITY FINDINGS &amp; LIFECYCLE MANAGEMENT
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer transition-colors ${
                filterSeverity === sev
                  ? 'bg-neutral-800 text-neutral-100 font-bold border border-neutral-600'
                  : 'bg-neutral-950 text-neutral-400 hover:text-neutral-200 border border-neutral-850'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2.5">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="p-3 rounded bg-neutral-950/70 border border-neutral-850 hover:border-neutral-700 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3"
          >
            <div className="space-y-1 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-neutral-100 text-xs font-mono">
                  {item.findingId}: {item.title}
                </span>

                <span className={`px-2 py-0.2 rounded text-[10px] font-mono font-bold border ${
                  item.severity === 'CRITICAL'
                    ? template.palette.badgeCritical
                    : item.severity === 'HIGH'
                    ? template.palette.badgeHigh
                    : item.severity === 'MEDIUM'
                    ? template.palette.badgeMedium
                    : template.palette.badgeLow
                }`}>
                  {item.severity}
                </span>

                <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-neutral-900 border border-neutral-800 text-neutral-400 flex items-center gap-1">
                  <Tag className="w-2.5 h-2.5" />
                  MITRE {item.mitreId} ({item.mitreTactic})
                </span>
              </div>

              <p className="text-[11px] text-neutral-400 font-mono">
                {item.description}
              </p>

              <div className="text-[10px] text-neutral-400 font-mono flex flex-wrap items-center gap-3">
                <span>Affected: <strong className="text-neutral-300">{item.affectedAsset}</strong></span>
                <span>Remediation: <span className="text-emerald-400">{item.remediation}</span></span>
              </div>
            </div>

            {/* Lifecycle Status & Selector */}
            <div className="flex items-center gap-2 flex-shrink-0 self-end md:self-auto">
              <select
                value={item.status}
                onChange={(e) => updateFindingStatus(item.id, e.target.value as FindingLifecycle)}
                className={`px-2 py-1 rounded text-[10px] font-mono font-bold border outline-none cursor-pointer ${
                  item.status === 'VALIDATED'
                    ? 'bg-red-950/80 text-red-300 border-red-800'
                    : item.status === 'REMEDIATED'
                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                    : 'bg-neutral-900 text-neutral-300 border-neutral-700'
                }`}
              >
                <option value="OPEN">OPEN</option>
                <option value="VALIDATED">VALIDATED</option>
                <option value="REMEDIATING">REMEDIATING</option>
                <option value="REMEDIATED">REMEDIATED</option>
                <option value="ACCEPTED">ACCEPTED</option>
                <option value="FALSE_POSITIVE">FALSE_POSITIVE</option>
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
