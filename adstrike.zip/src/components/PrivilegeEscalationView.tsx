import React, { useState } from 'react';
import {
  TrendingUp,
  ShieldAlert,
  Zap,
  Lock,
  Terminal,
  CheckCircle2,
  Copy,
  AlertTriangle,
  Database,
  Eye,
  EyeOff,
  ShieldCheck
} from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface PrivilegeEscalationViewProps {
  template: InterfaceTemplate;
  onNavigateToVault?: () => void;
}

export const PrivilegeEscalationView: React.FC<PrivilegeEscalationViewProps> = ({
  template,
  onNavigateToVault,
}) => {
  const [dcsyncResult, setDcsyncResult] = useState<any>(null);
  const [dcsyncLoading, setDcsyncLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState('Administrator');
  const [copied, setCopied] = useState(false);
  const [safetyConfirmed, setSafetyConfirmed] = useState(false);
  const [showHash, setShowHash] = useState(false);

  const handleDcsync = async () => {
    if (!safetyConfirmed) return;
    setDcsyncLoading(true);
    try {
      const res = await fetch('/api/attack/dcsync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user: selectedUser })
      });
      if (res.ok) {
        const data = await res.json();
        setDcsyncResult(data);
      }
    } catch {
      // Error
    } finally {
      setDcsyncLoading(false);
    }
  };

  const copyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} flex flex-col md:flex-row md:items-center justify-between gap-3`}>
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-red-950/80 border border-red-800/60 text-red-400">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
                PRIVILEGE ESCALATION &amp; DCSYNC DIRECTORY REPLICATION
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700">
                🟡 LAB SIMULATION / VALIDATED PRIVILEGES
              </span>
            </div>
            <p className="text-[11px] text-neutral-400">
              Validating extended access rights (DS-Replication-Get-Changes-All) and delegation vectors
            </p>
          </div>
        </div>

        <button
          onClick={onNavigateToVault}
          className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 flex items-center gap-2 cursor-pointer transition-colors"
        >
          <Database className="w-4 h-4 text-red-400" />
          <span>Evidence Vault</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* DCSync Simulator */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-4 shadow-xl`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/60 font-bold text-[10px]">
                MITRE T1003.006
              </span>
              <h4 className="font-bold text-neutral-200 text-xs">
                DCSYNC ATTACK (secretsdump.py)
              </h4>
            </div>
            <span className="text-[10px] text-red-400 font-bold">
              CRITICAL PRIVILEGE
            </span>
          </div>

          <p className="text-[11px] text-neutral-400 leading-relaxed">
            The <strong className="text-neutral-200">SQLAdmins</strong> group has been granted extended directory replication rights (<code className="text-red-300">DS-Replication-Get-Changes-All</code>). This allows pulling password hashes directly from the Domain Controller via MS-DRSR without code execution on the DC.
          </p>

          <div className="p-3 rounded bg-neutral-950 border border-neutral-850 space-y-2 text-[10px]">
            <div className="flex justify-between text-neutral-400">
              <span>Domain Controller:</span>
              <span className="text-neutral-200 font-bold">DC01.adstrike.local (192.168.56.10)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Exploited Principal:</span>
              <span className="text-neutral-200 font-bold">ADSTRIKE\svc_mssql (Member of SQLAdmins)</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Target Account to Sync:</span>
              <select
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                className="bg-neutral-900 text-neutral-200 border border-neutral-700 rounded px-2 py-0.5 outline-none font-bold"
              >
                <option value="Administrator">Administrator (RID 500)</option>
                <option value="krbtgt">krbtgt (RID 502 - Golden Ticket)</option>
                <option value="backup_operator">backup_operator (RID 1108)</option>
              </select>
            </div>
          </div>

          {/* Safety Verification Gate */}
          <div className="p-2.5 rounded bg-neutral-950 border border-neutral-850 flex items-center gap-2 text-[11px]">
            <input
              type="checkbox"
              id="dcsyncSafety"
              checked={safetyConfirmed}
              onChange={(e) => setSafetyConfirmed(e.target.checked)}
              className="accent-red-600 rounded cursor-pointer w-4 h-4"
            />
            <label htmlFor="dcsyncSafety" className="text-neutral-300 cursor-pointer select-none">
              I verify authorized lab engagement context for DRSUAPI credential synchronization
            </label>
          </div>

          <button
            onClick={handleDcsync}
            disabled={dcsyncLoading || !safetyConfirmed}
            className="w-full py-2 rounded bg-red-700 hover:bg-red-600 disabled:opacity-40 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-colors"
          >
            <Zap className={`w-4 h-4 ${dcsyncLoading ? 'animate-spin' : ''}`} />
            <span>{dcsyncLoading ? 'REPLICATING NTDS.DIT...' : `TRIGGER DCSYNC FOR ${selectedUser.toUpperCase()}`}</span>
          </button>

          {dcsyncResult && (
            <div className="p-3 rounded-lg bg-neutral-950 border border-red-900/50 space-y-2.5">
              <div className="flex items-center justify-between text-[10px] text-red-400 font-bold">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>NTDS.DIT HASH REPLICATED VIA DRSUAPI</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowHash(!showHash)}
                    className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                  >
                    {showHash ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showHash ? 'Mask' : 'Reveal'}</span>
                  </button>
                  <button
                    onClick={() => copyHash(dcsyncResult.rawNtdsLine)}
                    className="text-neutral-400 hover:text-neutral-200 flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copied ? 'COPIED!' : 'COPY LINE'}</span>
                  </button>
                </div>
              </div>

              <div className="p-2 rounded bg-black/70 border border-neutral-800 text-[10px] text-emerald-400 font-mono break-all">
                {showHash
                  ? dcsyncResult.rawNtdsLine
                  : dcsyncResult.rawNtdsLine.split(':')[0] + ':500:aad3b435b51404eeaad3b435b51404ee:[MASKED_FOR_SAFETY]:::'}
              </div>

              <div className="text-[10px] text-neutral-400 flex justify-between">
                <span>NTLM Hash:</span>
                <span className="text-neutral-200 font-mono">
                  {showHash ? dcsyncResult.ntlmHash : '••••••••••••••••••••••••••••••••'}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Unconstrained Delegation Analysis Card */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-4 shadow-xl`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/60 font-bold text-[10px]">
                MITRE T1558.001
              </span>
              <h4 className="font-bold text-neutral-200 text-xs">
                UNCONSTRAINED KERBEROS DELEGATION
              </h4>
            </div>
            <span className="text-[10px] text-amber-400 font-bold">
              WIN-SRV-01$
            </span>
          </div>

          <p className="text-[11px] text-neutral-400 leading-relaxed">
            Member server <strong className="text-neutral-200">WIN-SRV-01.adstrike.local (192.168.56.30)</strong> has the <code className="text-amber-300">TRUSTED_FOR_DELEGATION</code> flag enabled in Active Directory.
          </p>

          <div className="p-3 rounded bg-neutral-950 border border-neutral-850 space-y-2 text-[10px]">
            <div className="font-bold text-neutral-200 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>THE EXPLOITATION VECTOR:</span>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-neutral-400">
              <li>An attacker compromises local administrator on WIN-SRV-01.</li>
              <li>Attacker uses the Printer Bug (MS-RPRN) or PetitPotam (MS-EFSR) to coerce authentication from the Domain Controller (<strong className="text-neutral-200">DC01$</strong>).</li>
              <li>Because WIN-SRV-01 has Unconstrained Delegation, DC01's Kerberos Ticket Granting Ticket (TGT) is sent and stored directly inside WIN-SRV-01's LSASS memory space.</li>
              <li>Attacker extracts DC01$'s TGT with Rubeus or Mimikatz, granting full Domain Controller privileges.</li>
            </ol>
          </div>

          <div className="p-3 rounded bg-neutral-950/60 border border-neutral-800 space-y-2">
            <span className="text-[10px] text-neutral-400 font-bold block">REMEDIATION GUIDANCE:</span>
            <ul className="list-disc list-inside text-[10px] text-neutral-400 space-y-1">
              <li>Disable <code className="text-neutral-200">TRUSTED_FOR_DELEGATION</code> on all non-DC member computers.</li>
              <li>Migrate service to Resource-Based Constrained Delegation (RBCD).</li>
              <li>Add all Domain Administrators to the <strong className="text-neutral-200">Protected Users</strong> security group.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
