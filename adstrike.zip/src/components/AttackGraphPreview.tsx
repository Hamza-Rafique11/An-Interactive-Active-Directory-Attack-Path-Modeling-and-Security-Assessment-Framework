import React, { useState } from 'react';
import { Route, AlertTriangle, ShieldCheck, Zap, Server, Monitor, User, Key, Users } from 'lucide-react';
import { InterfaceTemplate, AttackNode, AttackEdge } from '../types';

interface AttackGraphPreviewProps {
  template: InterfaceTemplate;
  nodes: AttackNode[];
  edges: AttackEdge[];
}

export const AttackGraphPreview: React.FC<AttackGraphPreviewProps> = ({
  template,
  nodes,
  edges
}) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-spn');
  const [filterMode, setFilterMode] = useState<'CRITICAL_ONLY' | 'ALL'>('ALL');

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  const getNodeIcon = (type: AttackNode['type']) => {
    switch (type) {
      case 'user':
        return User;
      case 'workstation':
        return Monitor;
      case 'server':
        return Server;
      case 'dc':
        return Server;
      case 'ticket':
        return Key;
      case 'group':
        return Users;
      default:
        return Server;
    }
  };

  return (
    <div className={`rounded-lg border ${template.palette.border} ${template.palette.bgCard} p-4 text-xs font-mono`}>
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-800/80 mb-3">
        <div className="flex items-center gap-2">
          <Route className={`w-4 h-4 ${template.palette.accentSecondary}`} />
          <div>
            <span className="font-bold text-sm text-neutral-100 font-mono">
              INTERACTIVE ATTACK PATH GRAPH
            </span>
            <span className="ml-2 text-[10px] px-2 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/60 uppercase">
              BloodHound-Compatible Topology
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterMode(filterMode === 'ALL' ? 'CRITICAL_ONLY' : 'ALL')}
            className={`px-2.5 py-1 rounded text-[11px] font-mono border cursor-pointer ${
              filterMode === 'CRITICAL_ONLY'
                ? 'bg-red-950 text-red-200 border-red-700 font-bold'
                : 'bg-neutral-900 text-neutral-400 border-neutral-800'
            }`}
          >
            {filterMode === 'CRITICAL_ONLY' ? 'Filtering: Critical Paths Only' : 'Filter: Show All Paths'}
          </button>
        </div>
      </div>

      {/* Visual Canvas Diagram */}
      <div className="relative w-full h-56 bg-neutral-950/90 rounded border border-neutral-900 overflow-hidden flex items-center justify-between px-4 sm:px-8">
        {/* Subtle grid lines background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />

        {/* Attack Vector Connecting Line */}
        <div className="absolute left-12 right-12 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-red-600 via-amber-500 to-red-500 z-0" />

        {/* Render Attack Nodes */}
        {nodes.map((node, index) => {
          const Icon = getNodeIcon(node.type);
          const isSelected = node.id === selectedNodeId;

          return (
            <div
              key={node.id}
              onClick={() => setSelectedNodeId(node.id)}
              className="relative z-10 flex flex-col items-center cursor-pointer group"
            >
              {/* Edge Label above node */}
              {index > 0 && (
                <span className="absolute -top-7 text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-900/90 text-red-400 border border-red-900/50 whitespace-nowrap shadow">
                  {edges[index - 1]?.relationship || 'ConnectsTo'}
                </span>
              )}

              {/* Node Icon Circle */}
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center border-2 transition-all ${
                  isSelected
                    ? 'border-red-500 bg-red-950/80 shadow-[0_0_20px_rgba(239,68,68,0.5)] scale-110'
                    : node.compromised
                    ? 'border-amber-500/80 bg-neutral-900 text-amber-400 group-hover:border-amber-400'
                    : 'border-neutral-700 bg-neutral-900 text-neutral-400 group-hover:border-neutral-500'
                }`}
              >
                <Icon className={`w-5 h-5 ${isSelected ? 'text-red-300' : 'text-neutral-200'}`} />
              </div>

              {/* Node Label Below */}
              <span className={`mt-2 text-[11px] font-mono font-bold text-center whitespace-nowrap px-1 rounded ${
                isSelected ? 'text-red-300 bg-red-950/60' : 'text-neutral-300'
              }`}>
                {node.label}
              </span>

              <span className="text-[9px] text-neutral-400 text-center font-mono">
                {node.type.toUpperCase()}
              </span>
            </div>
          );
        })}
      </div>

      {/* Selected Node Details Drawer */}
      <div className="mt-3 p-3 rounded bg-neutral-950/80 border border-neutral-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-neutral-400">Selected Pivot Point:</span>
            <strong className="text-neutral-100 font-mono">{selectedNode.label}</strong>
            <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
              selectedNode.compromised ? 'bg-red-900/40 text-red-300 border border-red-700/50' : 'bg-neutral-800 text-neutral-300'
            }`}>
              {selectedNode.compromised ? 'COMPROMISED HOST/IDENTITY' : 'UNCOMPROMISED TARGET'}
            </span>
          </div>
          <p className="text-[11px] text-neutral-400 mt-1 font-mono">
            {selectedNode.roleDescription} • Technique vector leverages Kerberos service tickets requesting unconstrained delegation to reach Domain Admins.
          </p>
        </div>

        <button className="px-3 py-1.5 rounded text-xs font-mono font-bold bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 self-start sm:self-auto cursor-pointer">
          Trace Sub-Path
        </button>
      </div>
    </div>
  );
};
