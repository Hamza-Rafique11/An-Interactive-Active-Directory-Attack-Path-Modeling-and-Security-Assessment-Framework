import React, { useState, useEffect } from 'react';
import { Network, Users, Server, Shield, KeyRound, AlertTriangle, CheckCircle2, Lock } from 'lucide-react';
import { InterfaceTemplate, ADUserAccount } from '../types';

interface ActiveDirectoryViewProps {
  template: InterfaceTemplate;
  onSelectUserForRoast?: (username: string, type: 'kerberoast' | 'asrep') => void;
}

export const ActiveDirectoryView: React.FC<ActiveDirectoryViewProps> = ({
  template,
  onSelectUserForRoast,
}) => {
  const [directoryData, setDirectoryData] = useState<any>(null);
  const [activeSubTab, setActiveSubTab] = useState<'users' | 'computers' | 'groups'>('users');
  const [searchFilter, setSearchFilter] = useState('');

  useEffect(() => {
    fetch('/api/ad/directory')
      .then(res => res.json())
      .then(data => setDirectoryData(data))
      .catch(() => {});
  }, []);

  const filteredUsers = directoryData?.users?.filter((u: ADUserAccount) =>
    u.sAMAccountName.toLowerCase().includes(searchFilter.toLowerCase()) ||
    u.displayName.toLowerCase().includes(searchFilter.toLowerCase()) ||
    u.uacFlags.some(f => f.toLowerCase().includes(searchFilter.toLowerCase()))
  ) || [];

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* AD Domain Forest Header Card */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-3`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded bg-indigo-950/80 border border-indigo-800/60 text-indigo-400">
              <Network className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
                  DOMAIN & FOREST TOPOLOGY: {directoryData?.domain?.fqdn || 'adstrike.local'}
                </h3>
                <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 font-bold text-[10px]">
                  ONLINE
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Primary KDC: {directoryData?.domain?.primaryDc} ({directoryData?.domain?.dcIp})
              </p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 rounded bg-neutral-900 border border-neutral-800 text-center">
              <span className="text-[10px] text-neutral-500 block">FUNCTIONAL LEVEL</span>
              <span className="text-indigo-400 font-bold text-xs">{directoryData?.domain?.forestFunctionalLevel || 'Windows 2016'}</span>
            </div>
            <div className="px-3 py-1.5 rounded bg-neutral-900 border border-neutral-800 text-center">
              <span className="text-[10px] text-neutral-500 block">ROASTABLE ACCOUNTS</span>
              <span className="text-red-400 font-bold text-xs">2 IDENTIFIED</span>
            </div>
          </div>
        </div>

        {/* Sub-tab switcher & filter */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-800 text-[11px]">
          <div className="flex items-center gap-1.5">
            {[
              { id: 'users', label: 'LDAP User Accounts', icon: Users, count: directoryData?.users?.length || 0 },
              { id: 'computers', label: 'Domain Computers & Delegation', icon: Server, count: directoryData?.computers?.length || 0 },
              { id: 'groups', label: 'Security Groups & Privileges', icon: Shield, count: directoryData?.groups?.length || 0 },
            ].map(tab => {
              const Icon = tab.icon;
              const active = activeSubTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveSubTab(tab.id as any)}
                  className={`px-3 py-1.5 rounded font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    active
                      ? 'bg-indigo-900/50 text-indigo-300 border border-indigo-700/60'
                      : 'bg-neutral-900/60 text-neutral-400 hover:text-neutral-200 border border-neutral-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  <span className="text-[10px] opacity-70">({tab.count})</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Filter sAMAccountName / flags..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1 text-xs text-neutral-200 placeholder-neutral-500 outline-none w-48"
            />
          </div>
        </div>
      </div>

      {/* View Content based on sub-tab */}
      {activeSubTab === 'users' && (
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} overflow-hidden shadow-xl`}>
          <div className="p-3 bg-neutral-900/80 border-b border-neutral-800 flex items-center justify-between">
            <span className="font-bold text-neutral-200 text-xs">
              ENUMERATED USER PRINCIPALS WITH USERACCOUNTCONTROL FLAGS
            </span>
            <span className="text-[10px] text-neutral-400">
              Query: LDAP sAMAccountType=805306368
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-[11px]">
              <thead>
                <tr className="bg-neutral-950/90 text-neutral-400 border-b border-neutral-800">
                  <th className="py-2.5 px-3">sAMAccountName</th>
                  <th className="py-2.5 px-3">DISPLAY NAME / OU</th>
                  <th className="py-2.5 px-3">UAC FLAGS & VULNERABILITIES</th>
                  <th className="py-2.5 px-3">SPNs REGISTERED</th>
                  <th className="py-2.5 px-3">ADMINCOUNT</th>
                  <th className="py-2.5 px-3">GROUPS</th>
                  <th className="py-2.5 px-3 text-right">EXPLOIT SIMULATION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-850">
                {filteredUsers.map((user: ADUserAccount) => (
                  <tr key={user.sAMAccountName} className="hover:bg-neutral-900/40 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-indigo-300">
                      {user.sAMAccountName}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-neutral-200 font-medium block">{user.displayName}</span>
                      <span className="text-neutral-500 text-[10px] truncate max-w-xs block">{user.distinguishedName}</span>
                    </td>
                    <td className="py-2.5 px-3 space-x-1">
                      {user.asrepRoastable && (
                        <span className="px-1.5 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/60 font-bold text-[10px]">
                          DONT_REQ_PREAUTH (AS-REP Roastable)
                        </span>
                      )}
                      {user.kerberoastable && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/60 font-bold text-[10px]">
                          SPN (Kerberoastable)
                        </span>
                      )}
                      {user.uacFlags.map(f => (
                        <span key={f} className="px-1.5 py-0.5 rounded bg-neutral-900 text-neutral-400 text-[10px]">
                          {f}
                        </span>
                      ))}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[10px]">
                      {user.servicePrincipalNames.length > 0 ? (
                        <span className="text-amber-400 font-semibold">
                          {user.servicePrincipalNames[0]}
                        </span>
                      ) : (
                        <span className="text-neutral-600">None</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      {user.adminCount ? (
                        <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800/60 text-[10px] font-bold">
                          PROTECTED (1)
                        </span>
                      ) : (
                        <span className="text-neutral-500 text-[10px]">0</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-neutral-300 text-[10px]">
                      {user.memberOf.join(', ')}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      {user.kerberoastable ? (
                        <button
                          onClick={() => onSelectUserForRoast?.(user.sAMAccountName, 'kerberoast')}
                          className="px-2.5 py-1 rounded bg-amber-900/60 hover:bg-amber-800 text-amber-200 border border-amber-700/60 text-[10px] font-bold cursor-pointer"
                        >
                          Request TGS
                        </button>
                      ) : user.asrepRoastable ? (
                        <button
                          onClick={() => onSelectUserForRoast?.(user.sAMAccountName, 'asrep')}
                          className="px-2.5 py-1 rounded bg-red-900/60 hover:bg-red-800 text-red-200 border border-red-700/60 text-[10px] font-bold cursor-pointer"
                        >
                          Harvest AS-REP
                        </button>
                      ) : (
                        <span className="text-neutral-600 text-[10px]">Standard User</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSubTab === 'computers' && (
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-3`}>
          <h4 className="font-bold text-neutral-200 text-xs">
            DOMAIN COMPUTERS & DELEGATION POLICIES (TRUSTED_FOR_DELEGATION)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {directoryData?.computers?.map((c: any) => (
              <div key={c.name} className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-neutral-200">{c.name}</span>
                  <span className="text-neutral-400 font-mono text-[10px]">{c.ip}</span>
                </div>
                <div className="text-[11px] text-neutral-400">{c.os}</div>
                <div className="pt-2 border-t border-neutral-850">
                  {c.unconstrainedDelegation ? (
                    <div className="p-2 rounded bg-red-950/60 border border-red-800/60 text-red-300 text-[10px] space-y-1">
                      <div className="font-bold flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        <span>UNCONSTRAINED KERBEROS DELEGATION</span>
                      </div>
                      <p className="text-neutral-400">
                        Caches TGTs in LSASS of any Domain Admin authenticating to this server.
                      </p>
                    </div>
                  ) : (
                    <div className="text-emerald-400 text-[10px] flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Standard delegation policy</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'groups' && (
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-3`}>
          <h4 className="font-bold text-neutral-200 text-xs">
            SECURITY GROUPS & PRIVILEGED EXTENDED ACCESS RIGHTS
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {directoryData?.groups?.map((g: any) => (
              <div key={g.name} className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-neutral-100">{g.name}</span>
                  <span className="text-indigo-400 text-[10px] font-bold">{g.privileges}</span>
                </div>
                <div className="text-[10px] text-neutral-400">
                  Members: <span className="text-neutral-200">{g.members.join(', ')}</span>
                </div>
                {g.name === 'SQLAdmins' && (
                  <div className="p-2 rounded bg-red-950/60 border border-red-800/50 text-red-300 text-[10px]">
                    <strong>CRITICAL PATH:</strong> Members possess Replicating Directory Changes right, enabling DCSync password extraction without code execution on DC.
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
