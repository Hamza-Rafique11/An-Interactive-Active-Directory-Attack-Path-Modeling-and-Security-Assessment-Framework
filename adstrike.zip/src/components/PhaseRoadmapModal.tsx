import React from 'react';
import { X, Layers, Database, Shield, Cpu, Terminal, Network, GitPullRequest, CheckCircle2 } from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface PhaseRoadmapModalProps {
  isOpen: boolean;
  onClose: () => void;
  template: InterfaceTemplate;
}

export const PhaseRoadmapModal: React.FC<PhaseRoadmapModalProps> = ({
  isOpen,
  onClose,
  template
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className={`w-full max-w-5xl rounded-xl border ${template.palette.border} ${template.palette.bgPanel} shadow-2xl p-6 text-neutral-200 text-xs font-mono max-h-[90vh] overflow-y-auto space-y-6`}>
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-red-950/80 text-red-400 border border-red-800/60">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-neutral-100 font-mono">
                ADSTRIKE // ARCHITECTURAL BLUEPRINT & 10-PHASE ROADMAP
              </h2>
              <p className="text-[11px] text-neutral-400 font-mono">
                Full-Stack System Architecture, Database Schema, and Execution Plan
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-neutral-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Section 1: Architecture Overview */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-neutral-100">
            <Cpu className="w-4 h-4 text-red-400" />
            <span>1. SYSTEM ARCHITECTURE & COMPONENT TOPOLOGY</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
            <div className="p-3 rounded bg-neutral-950/80 border border-neutral-850 space-y-1.5">
              <div className="font-bold text-neutral-200">Kali / Controller Host (Linux)</div>
              <ul className="list-disc list-inside space-y-1 text-neutral-400">
                <li>Runs ADStrike Backend (Node.js/Express + Prisma ORM)</li>
                <li>WebSocket Real-Time Event Dispatcher for live telemetry</li>
                <li>Discovery & Recon: Nmap 7.94+, ARP sweeps, TCP port probing</li>
                <li>Kerberos / LDAP Tooling: Impacket suite (GetUserSPNs.py, secretsdump.py), ldapsearch</li>
              </ul>
            </div>
            <div className="p-3 rounded bg-neutral-950/80 border border-neutral-850 space-y-1.5">
              <div className="font-bold text-neutral-200">Windows / AD Target Lab (192.168.56.0/24)</div>
              <ul className="list-disc list-inside space-y-1 text-neutral-400">
                <li><strong>DC01</strong> (192.168.56.10): Windows Server 2022 AD DS, DNS, Kerberos KDC, LDAP</li>
                <li><strong>WIN10-01</strong> (192.168.56.20): Windows 10 Pro workstation (SMB Signing audit target)</li>
                <li><strong>WIN-SRV-01</strong> (192.168.56.30): Member Server (MSSQL SPN, Unconstrained Delegation)</li>
                <li><strong>LINUX01</strong> (192.168.56.40): Ubuntu 22.04 LTS joined via SSSD</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Section 2: Database Schema (Prisma) */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-neutral-100">
            <Database className="w-4 h-4 text-red-400" />
            <span>2. PRISMA RELATIONAL DATA MODEL</span>
          </div>
          <div className="p-3 rounded bg-neutral-950/90 border border-neutral-850 font-mono text-[10px] text-neutral-300 overflow-x-auto">
            <pre>{`model Assessment {
  id              String         @id @default(uuid())
  name            String
  operator        String
  authorizedScope String         // CIDR e.g. 192.168.56.0/24
  excludedHosts   String[]
  status          AssessmentStatus // DRAFT, ACTIVE, COMPLETED, SUSPENDED
  targets         Target[]
  findings        Finding[]
  evidence        Evidence[]
  attackPaths     AttackPath[]
  auditLogs       AuditLog[]
}

model Target {
  id             String    @id @default(uuid())
  ip             String
  hostname       String
  os             String?
  role           TargetRole // DC, WORKSTATION, SERVER, LINUX
  openPorts      Port[]
  adUsers        ADUser[]
  adGroups       ADGroup[]
  riskScore      Float
}

model Finding {
  id             String         @id @default(uuid())
  findingId      String         @unique // AD-FIND-001
  title          String
  severity       SeverityLevel  // CRITICAL, HIGH, MEDIUM, LOW, INFO
  mitreTechnique String         // T1558.003
  targetId       String
  status         FindingStatus  // IDENTIFIED, VALIDATED, REMEDIATED
  evidenceId     String?
}`}</pre>
          </div>
        </div>

        {/* Section 3: 10-Phase Roadmap */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-neutral-100">
            <GitPullRequest className="w-4 h-4 text-red-400" />
            <span>3. 10-PHASE MASTER EXECUTION ROADMAP</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
            {[
              { phase: 'Phase 1', title: 'Architecture, Workspace & Interface Design System', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 2', title: 'Express Backend, Prisma Schema & Scope Enforcement Engine', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 3', title: 'Frontend Foundation, 18-Route Navigation & State Manager', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 4', title: 'Authorized Discovery & Port/Service Enumeration Engine', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 5', title: 'SMB, LDAP & Active Directory Telemetry Modules', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 6', title: 'Kerberos & Privilege Escalation Assessment Workflows', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 7', title: 'Interactive Attack-Path Graph (BloodHound-Compatible)', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 8', title: 'Evidence Repository, SHA-256 Vault & MITRE Findings', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 9', title: 'Executive Penetration Testing Report Generator (PDF/HTML)', status: 'COMPLETED / LIVE' },
              { phase: 'Phase 10', title: 'Demo Mode, Lab Configuration & Security Hardening', status: 'COMPLETED / LIVE' },
            ].map((p, i) => (
              <div key={i} className="p-2.5 rounded bg-neutral-950/70 border border-neutral-850 flex items-center justify-between">
                <div>
                  <span className="font-bold text-emerald-400">{p.phase}: </span>
                  <span className="text-neutral-200">{p.title}</span>
                </div>
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ml-2 whitespace-nowrap bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 flex items-center gap-1`}>
                  <CheckCircle2 className="w-2.5 h-2.5" />
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded text-xs font-mono font-bold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 cursor-pointer"
          >
            Close Blueprint
          </button>
        </div>
      </div>
    </div>
  );
};
