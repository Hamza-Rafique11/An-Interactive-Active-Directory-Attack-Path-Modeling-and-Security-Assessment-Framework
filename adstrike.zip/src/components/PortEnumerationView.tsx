import React, { useState, useEffect } from 'react';
import {
  ListTree,
  Play,
  Terminal,
  ShieldAlert,
  ShieldCheck,
  AlertCircle,
  RefreshCw,
  Cpu,
  Lock
} from 'lucide-react';
import { InterfaceTemplate, PortScanItem, ExecutionMode } from '../types';

interface PortEnumerationViewProps {
  template: InterfaceTemplate;
  defaultTarget?: string;
}

export const PortEnumerationView: React.FC<PortEnumerationViewProps> = ({
  template,
  defaultTarget = '192.168.56.10',
}) => {
  const [targetIp, setTargetIp] = useState(defaultTarget);
  const [scanProfile, setScanProfile] = useState('-sS -sV -sC -Pn');
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('AUTO');
  const [loading, setLoading] = useState(false);
  const [scopeError, setScopeError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<{
    ports: PortScanItem[];
    smbSigningSummary: string;
    rawNmapOutput: string[];
    executionMode?: string;
    target?: string;
    engine?: string;
  } | null>(null);
  const [showRawOutput, setShowRawOutput] = useState(false);

  const executePortScan = async (ip: string, flags: string, mode: ExecutionMode) => {
    setLoading(true);
    setScopeError(null);

    try {
      const res = await fetch('/api/enumeration/ports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip, flags, executionMode: mode })
      });

      const data = await res.json();

      if (res.status === 403) {
        setScopeError(data.message || data.error || 'TARGET OUT OF SCOPE');
        setScanResult(null);
      } else if (res.ok) {
        setScanResult({
          ports: data.ports || [],
          smbSigningSummary: data.smbSigningSummary,
          rawNmapOutput: data.rawNmapOutput || [],
          executionMode: data.executionMode,
          target: data.target,
          engine: data.engine
        });
      }
    } catch (err: any) {
      setScopeError(`Scan failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    executePortScan(targetIp, scanProfile, executionMode);
  }, []);

  const handleRunScan = () => {
    executePortScan(targetIp, scanProfile, executionMode);
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Scope violation warning */}
      {scopeError && (
        <div className="p-3.5 rounded-xl bg-red-950/90 border border-red-800 text-red-300 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <span className="font-bold block">SCOPE GUARD PREVENTED OPERATION:</span>
              <span className="text-[11px] text-red-300">{scopeError}</span>
            </div>
          </div>
          <button
            onClick={() => {
              setTargetIp('192.168.56.10');
              setScopeError(null);
            }}
            className="px-2.5 py-1 rounded bg-red-900/80 hover:bg-red-800 text-white text-[10px] font-bold border border-red-700 cursor-pointer"
          >
            Reset to DC01
          </button>
        </div>
      )}

      {/* Control Card */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-3`}>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded bg-cyan-950/70 border border-cyan-800/60 text-cyan-400">
              <ListTree className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
                  PORT, PROTOCOL &amp; SMB SIGNING PROBE ENGINE
                </h3>
                {scanResult?.executionMode && (
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    scanResult.executionMode === 'REAL'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                      : 'bg-amber-950 text-amber-300 border border-amber-700'
                  }`}>
                    {scanResult.executionMode === 'REAL' ? '🟢 REAL LAB PROBE' : '🟡 DEMO / SIMULATION'}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-neutral-400">
                Native Node.js raw TCP connect socket + SMB2 negotiate protocol analyzer
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Mode Select */}
            <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-700 rounded px-2 py-1">
              <span className="text-[10px] text-neutral-400">Mode:</span>
              <select
                value={executionMode}
                onChange={(e) => setExecutionMode(e.target.value as ExecutionMode)}
                className="bg-transparent text-cyan-300 font-bold outline-none cursor-pointer text-xs"
              >
                <option value="AUTO">AUTO (Real Probe + Fallback)</option>
                <option value="REAL">REAL ONLY (TCP Net.Socket)</option>
                <option value="SIMULATED">SIMULATED (Offline Lab Matrix)</option>
              </select>
            </div>

            {/* Target Select or Input */}
            <div className="flex items-center gap-1.5 bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs">
              <span className="text-neutral-400">Target IP:</span>
              <input
                type="text"
                value={targetIp}
                onChange={(e) => setTargetIp(e.target.value)}
                className="bg-transparent text-cyan-300 font-bold outline-none font-mono w-32"
              />
            </div>

            <select
              value={scanProfile}
              onChange={(e) => setScanProfile(e.target.value)}
              className="bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-neutral-200 outline-none"
            >
              <option value="-sS -sV -sC -Pn">Standard AD (-sS -sV -sC)</option>
              <option value="-p 88,135,389,445,636,3268 -sV">Core AD Ports (88, 135, 389, 445)</option>
              <option value="-p 445 --script smb2-security-mode">SMB Signing Audit Only</option>
              <option value="-p- -T4">Full Range 1-65535</option>
            </select>

            <button
              onClick={handleRunScan}
              disabled={loading}
              className="px-4 py-1.5 rounded font-bold bg-cyan-700 hover:bg-cyan-600 disabled:opacity-50 text-white flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Play className={`w-3.5 h-3.5 fill-current ${loading ? 'animate-pulse' : ''}`} />
              <span>{loading ? 'PROBING...' : 'DISPATCH PROBE'}</span>
            </button>
          </div>
        </div>

        {/* Security Posture Warning / Banner */}
        {scanResult && (
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-800/80 text-[11px]">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-neutral-400">SMB Signing Security:</span>
                <span className={`px-2 py-0.5 rounded font-bold flex items-center gap-1 ${
                  scanResult.smbSigningSummary.includes('ENFORCED')
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60'
                    : 'bg-red-950/80 text-red-400 border border-red-800/60'
                }`}>
                  {scanResult.smbSigningSummary.includes('ENFORCED') ? (
                    <ShieldCheck className="w-3 h-3" />
                  ) : (
                    <AlertCircle className="w-3 h-3" />
                  )}
                  {scanResult.smbSigningSummary}
                </span>
              </div>

              {scanResult.engine && (
                <span className="text-[10px] text-neutral-400">
                  Engine: <code className="text-neutral-300">{scanResult.engine}</code>
                </span>
              )}
            </div>

            <button
              onClick={() => setShowRawOutput(!showRawOutput)}
              className="text-neutral-400 hover:text-cyan-400 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{showRawOutput ? 'Hide CLI Telemetry Log' : 'View Raw Engine Output'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Raw Output Terminal Accordion */}
      {showRawOutput && scanResult && (
        <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-300 font-mono text-[10px] space-y-1">
          <div className="text-neutral-400 font-bold flex items-center justify-between pb-1 border-b border-neutral-850">
            <span>ENGINE EXECUTION TELEMETRY // {scanResult.engine || 'ADSTRIKE CORE'}</span>
            <span className="text-cyan-400">STATUS: 0 EXIT CODE</span>
          </div>
          <pre className="overflow-x-auto leading-relaxed text-neutral-300">
            {scanResult.rawNmapOutput.join('\n')}
          </pre>
        </div>
      )}

      {/* Port Matrix Table */}
      <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} overflow-hidden shadow-xl`}>
        <div className="p-3 bg-neutral-900/80 border-b border-neutral-800 flex items-center justify-between">
          <span className="font-bold text-neutral-200 text-xs flex items-center gap-2">
            <span>PORT MATRIX: {targetIp}</span>
            <span className="px-1.5 py-0.5 rounded bg-neutral-800 text-[10px] text-cyan-400">
              {scanResult?.ports.length || 0} OPEN PORTS
            </span>
          </span>
          <span className="text-[10px] text-neutral-400 font-mono">
            Flags: {scanProfile}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="bg-neutral-950/90 text-neutral-400 border-b border-neutral-800">
                <th className="py-2.5 px-3">PORT / PROTOCOL</th>
                <th className="py-2.5 px-3">STATE</th>
                <th className="py-2.5 px-3">SERVICE</th>
                <th className="py-2.5 px-3">BANNER &amp; TELEMETRY</th>
                <th className="py-2.5 px-3">PROBE METHOD</th>
                <th className="py-2.5 px-3">SMB SIGNING</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-850">
              {scanResult?.ports.map((item) => (
                <tr key={`${item.port}-${item.protocol}`} className="hover:bg-neutral-900/40 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-cyan-400 font-mono">
                    {item.port}/{item.protocol}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 font-bold text-[10px]">
                      {item.state.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-neutral-200 font-semibold">
                    {item.service}
                  </td>
                  <td className="py-2.5 px-3 text-neutral-400 font-mono text-[10px]">
                    {item.version}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-neutral-900 border border-neutral-800 text-neutral-300">
                      {item.probeMethod || 'SOCKET_CONNECT'}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    {item.port === 445 ? (
                      item.smbSigning === 'REQUIRED' ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 font-bold text-[10px]">
                          ENFORCED (SECURE)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800/60 font-bold text-[10px] animate-pulse">
                          DISABLED (VULN TO RELAY)
                        </span>
                      )
                    ) : (
                      <span className="text-neutral-400 text-[10px]">-</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
