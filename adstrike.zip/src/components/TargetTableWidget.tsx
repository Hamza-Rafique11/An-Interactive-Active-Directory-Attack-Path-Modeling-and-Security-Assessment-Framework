import React from 'react';
import { Crosshair, Server, ShieldAlert, Check, ExternalLink, Activity } from 'lucide-react';
import { InterfaceTemplate, LabTarget } from '../types';

interface TargetTableWidgetProps {
  template: InterfaceTemplate;
  targets: LabTarget[];
}

export const TargetTableWidget: React.FC<TargetTableWidgetProps> = ({
  template,
  targets
}) => {
  return (
    <div className={`rounded-lg border ${template.palette.border} ${template.palette.bgCard} p-4 text-xs font-mono`}>
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-800/80 mb-3">
        <div className="flex items-center gap-2">
          <Crosshair className={`w-4 h-4 ${template.palette.accentSecondary}`} />
          <span className="font-bold text-sm text-neutral-100 font-mono">
            AUTHORIZED TARGET INVENTORY ({targets.length} HOSTS)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 font-mono">
            Subnet: 192.168.56.0/24 (Host-Only Virtual Network)
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-neutral-800 text-[10px] uppercase text-neutral-400 font-mono">
              <th className="py-2 px-2">Target Host</th>
              <th className="py-2 px-2">Operating System</th>
              <th className="py-2 px-2">Domain Role</th>
              <th className="py-2 px-2">Key Open Ports</th>
              <th className="py-2 px-2">Risk</th>
              <th className="py-2 px-2">Status</th>
              <th className="py-2 px-2 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-850">
            {targets.map((target) => (
              <tr key={target.id} className="hover:bg-neutral-900/50 transition-colors">
                {/* Host Info */}
                <td className="py-2.5 px-2">
                  <div className="font-bold text-neutral-100 font-mono">{target.hostname}</div>
                  <div className="text-[11px] text-neutral-400 font-mono">{target.ip}</div>
                </td>

                {/* OS */}
                <td className="py-2.5 px-2 text-neutral-300 font-mono text-[11px]">
                  {target.os}
                </td>

                {/* Role */}
                <td className="py-2.5 px-2">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono ${
                    target.role === 'Domain Controller'
                      ? 'bg-red-950/80 text-red-300 border border-red-800/60 font-bold'
                      : target.role === 'Member Server'
                      ? 'bg-amber-950/70 text-amber-300 border border-amber-800/50'
                      : target.role === 'Workstation'
                      ? 'bg-blue-950/70 text-blue-300 border border-blue-800/50'
                      : 'bg-neutral-800 text-neutral-300 border border-neutral-700'
                  }`}>
                    <Server className="w-3 h-3" />
                    {target.role}
                  </span>
                </td>

                {/* Open Ports */}
                <td className="py-2.5 px-2">
                  <div className="flex flex-wrap gap-1 max-w-xs">
                    {target.openPorts.slice(0, 5).map((port) => (
                      <span
                        key={port}
                        className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${
                          port === 88 || port === 389 || port === 445
                            ? 'bg-neutral-800 text-red-300 font-bold border border-red-900/40'
                            : 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                        }`}
                        title={
                          port === 88 ? 'Kerberos KDC' : port === 389 ? 'LDAP' : port === 445 ? 'SMB' : `Port ${port}`
                        }
                      >
                        {port}
                        {port === 88 && ' (Kerb)'}
                        {port === 389 && ' (LDAP)'}
                        {port === 445 && ' (SMB)'}
                      </span>
                    ))}
                    {target.openPorts.length > 5 && (
                      <span className="text-[9px] px-1 py-0.5 rounded bg-neutral-900 text-neutral-400 font-mono">
                        +{target.openPorts.length - 5}
                      </span>
                    )}
                  </div>
                </td>

                {/* Risk */}
                <td className="py-2.5 px-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                    target.risk === 'CRITICAL'
                      ? template.palette.badgeCritical
                      : target.risk === 'HIGH'
                      ? template.palette.badgeHigh
                      : target.risk === 'MEDIUM'
                      ? template.palette.badgeMedium
                      : template.palette.badgeLow
                  }`}>
                    {target.risk}
                  </span>
                </td>

                {/* Status */}
                <td className="py-2.5 px-2">
                  <div className="flex items-center gap-1.5 text-[11px] font-mono text-emerald-400">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
                    <span>{target.status}</span>
                  </div>
                  <div className="text-[10px] text-neutral-400 font-mono">{target.lastSeen}</div>
                </td>

                {/* Action */}
                <td className="py-2.5 px-2 text-right">
                  <button className="px-2.5 py-1 rounded text-[10px] font-mono font-bold bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 cursor-pointer">
                    Enumerate
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
