import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Printer,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Server,
  Award,
  ExternalLink
} from 'lucide-react';
import { InterfaceTemplate, FindingItem } from '../types';

interface ExecutiveReportViewProps {
  template: InterfaceTemplate;
  findings: FindingItem[];
}

export const ExecutiveReportView: React.FC<ExecutiveReportViewProps> = ({
  template,
  findings
}) => {
  const [reportData, setReportData] = useState<any>(null);
  const [generating, setGenerating] = useState<boolean>(false);

  const fetchReport = () => {
    setGenerating(true);
    fetch('/api/reports/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'ADStrike Enterprise Active Directory Penetration Test' })
    })
      .then((res) => res.json())
      .then((data) => setReportData(data))
      .catch((err) => console.error('Error generating report:', err))
      .finally(() => setGenerating(false));
  };

  useEffect(() => {
    fetchReport();
  }, []);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Action Header */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-red-950 text-red-400 border border-red-800">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100">
                ACTIVE DIRECTORY SECURITY ASSESSMENT REPORT
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
                CONFIDENTIAL / RED-TEAM LAB
              </span>
            </div>
            <p className="text-neutral-400 text-xs mt-0.5">
              Comprehensive technical and executive findings compliant with MITRE ATT&CK Enterprise Framework.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchReport}
            disabled={generating}
            className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 cursor-pointer text-xs"
          >
            Regenerate
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-700 hover:bg-cyan-600 text-white font-bold cursor-pointer text-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Report Document Sheet */}
      <div className="p-6 md:p-8 rounded-xl border border-neutral-800 bg-neutral-950 space-y-6 text-neutral-300 shadow-2xl">
        {/* Title Block */}
        <div className="border-b border-neutral-800 pb-6 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-neutral-400 uppercase">
            <span>Assessment Engagement: ADStrike Lab</span>
            <span>Date: {reportData?.date || '2026-09-13'}</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-neutral-100">
            Active Directory Penetration Test &amp; Privilege Escalation Audit
          </h1>
          <div className="flex flex-wrap gap-4 text-xs text-neutral-400 pt-2">
            <span>Target Environment: <strong className="text-neutral-200">adstrike.local (192.168.56.0/24)</strong></span>
            <span>Overall Posture: <strong className="text-red-400">CRITICAL COMPROMISE ACHIEVED</strong></span>
            <span>Lead Operator: <strong className="text-neutral-200">sec-ops@kali</strong></span>
          </div>
        </div>

        {/* Executive Summary Section */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-neutral-100 border-l-2 border-red-500 pl-2 uppercase">
            1. Executive Summary &amp; Compromise Narrative
          </h2>
          <p className="text-xs text-neutral-300 leading-relaxed">
            During the authorized red-team assessment against <strong>adstrike.local</strong> within the isolated laboratory subnet <code>192.168.56.0/24</code>, security operators successfully achieved full administrative compromise of the Active Directory domain controller (<strong>DC01.adstrike.local</strong>).
          </p>
          <p className="text-xs text-neutral-400 leading-relaxed">
            The kill-chain originated from standard domain credentials (<code>jdoe</code>). Through targeted reconnaissance, the operators requested an RC4-HMAC encrypted Kerberos TGS ticket for <code>svc_mssql</code> (Kerberoasting, T1558.003), identified membership in the privileged <code>SQLAdmins</code> group, exploited unconstrained Kerberos delegation on <code>WIN-SRV-01</code> (T1558.001), and finally executed a DRSUAPI DCSync attack (T1003.006) to extract NTDS.dit domain credentials.
          </p>
        </div>

        {/* Key Metrics Bento */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-2">
          <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
            <div className="text-[10px] uppercase text-neutral-400 font-bold">Critical Vulnerabilities</div>
            <div className="text-2xl font-bold text-red-400 mt-1">
              {findings.filter(f => f.severity === 'CRITICAL').length}
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Immediate exploitation</div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
            <div className="text-[10px] uppercase text-neutral-400 font-bold">High Severity</div>
            <div className="text-2xl font-bold text-amber-400 mt-1">
              {findings.filter(f => f.severity === 'HIGH').length}
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">AS-REP / Relay paths</div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
            <div className="text-[10px] uppercase text-neutral-400 font-bold">Domain Status</div>
            <div className="text-2xl font-bold text-red-500 mt-1">PWNED</div>
            <div className="text-[10px] text-neutral-400 mt-0.5">DCSync verified</div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
            <div className="text-[10px] uppercase text-neutral-400 font-bold">Evidence Artifacts</div>
            <div className="text-2xl font-bold text-cyan-400 mt-1">
              {reportData?.evidenceItems || 3}
            </div>
            <div className="text-[10px] text-neutral-400 mt-0.5">Hashed with SHA-256</div>
          </div>
        </div>

        {/* Technical Findings Summary Table */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-neutral-100 border-l-2 border-amber-500 pl-2 uppercase">
            2. Verified Vulnerabilities &amp; MITRE ATT&CK Mapping
          </h2>
          <div className="overflow-x-auto border border-neutral-800 rounded-lg">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-neutral-800 bg-neutral-900/80 text-[10px] uppercase font-bold text-neutral-400">
                  <th className="py-2.5 px-3">ID</th>
                  <th className="py-2.5 px-3">Severity</th>
                  <th className="py-2.5 px-3">Title</th>
                  <th className="py-2.5 px-3">MITRE ID</th>
                  <th className="py-2.5 px-3">Affected Asset</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-850">
                {findings.map((f) => (
                  <tr key={f.id} className="hover:bg-neutral-900/30">
                    <td className="py-2 px-3 text-neutral-400 font-bold">{f.findingId}</td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        f.severity === 'CRITICAL'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {f.severity}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-neutral-200 font-bold">{f.title}</td>
                    <td className="py-2 px-3 text-cyan-300">{f.mitreId}</td>
                    <td className="py-2 px-3 text-neutral-300">{f.affectedAsset}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Remediation Action Plan */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-neutral-100 border-l-2 border-emerald-500 pl-2 uppercase">
            3. Prioritized Strategic Remediations
          </h2>
          <div className="space-y-2">
            {(reportData?.recommendations || [
              'Enforce AES256-CTS-HMAC-SHA1-96 for Kerberos Service Principal Names and disable RC4-HMAC.',
              'Revoke TRUSTED_FOR_DELEGATION attribute on member servers.',
              'Audit Replicating Directory Changes permissions and restrict DRSUAPI access to Domain Controllers only.'
            ]).map((rec: string, i: number) => (
              <div key={i} className="flex items-start gap-2.5 p-2.5 rounded bg-neutral-900 border border-neutral-850">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <span className="text-xs text-neutral-200 leading-relaxed">{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
