import React, { useState } from 'react';
import { Terminal, Play, CheckCircle2, Clock, Shield, RefreshCw } from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface TerminalWidgetProps {
  template: InterfaceTemplate;
}

export const TerminalWidget: React.FC<TerminalWidgetProps> = ({ template }) => {
  const [selectedCommand, setSelectedCommand] = useState<string>('GetUserSPNs.py adstrike.local/jdoe:Password123! -dc-ip 192.168.56.10 -request');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([
    '[*] ADStrike Assessment Engine v1.0 [AUTHORIZED LAB MODE]',
    '[*] Target Scope Verified: 192.168.56.0/24 (Target: 192.168.56.10 DC01)',
    '[*] Pre-execution Safety Check: PASS (Explicit Lab Authorization Valid)',
    '$ GetUserSPNs.py adstrike.local/jdoe:Password123! -dc-ip 192.168.56.10 -request',
    '[*] Requesting TGS ticket for SPN: MSSQLSvc/WIN-SRV-01.adstrike.local:1433',
    '[+] Received TGS ticket for user: svc_mssql (Format: $krb5tgs$23$*svc_mssql*adstrike.local*)',
    '[!] Hash extracted (RC4-HMAC cipher detected). Saving artifact to Evidence Vault (ID: EVD-0042).',
    '[+] Command completed successfully. [Exit code: 0 | Duration: 342ms]'
  ]);

  const runSimulatedCommand = (cmd: string) => {
    setSelectedCommand(cmd);
    setIsRunning(true);
    setLogs([
      `[*] Target Scope Verified: 192.168.56.0/24`,
      `$ ${cmd}`,
      `[*] Connecting to authorized target...`
    ]);

    setTimeout(() => {
      if (cmd.includes('nmap')) {
        setLogs((prev) => [
          ...prev,
          `Starting Nmap 7.94 at 2026-09-13 12:44 UTC`,
          `Nmap scan report for DC01.adstrike.local (192.168.56.10)`,
          `PORT    STATE SERVICE      VERSION`,
          `53/tcp  open  domain       Simple DNS Plus`,
          `88/tcp  open  kerberos-sec Microsoft Windows Kerberos`,
          `135/tcp open  msrpc        Microsoft Windows RPC`,
          `389/tcp open  ldap         Microsoft Windows Active Directory LDAP`,
          `445/tcp open  microsoft-ds Windows Server 2022 Standard SMB`,
          `[+] Nmap completed: 1 host up scanned in 1.42 seconds. [Exit: 0]`
        ]);
      } else if (cmd.includes('PreAuth')) {
        setLogs((prev) => [
          ...prev,
          `PS C:\\> Get-ADUser -Filter 'DoesNotRequirePreAuth -eq $True' -Properties DoesNotRequirePreAuth`,
          `DistinguishedName : CN=backup_operator,CN=Users,DC=adstrike,DC=local`,
          `Enabled           : True`,
          `SamAccountName    : backup_operator`,
          `[!] CRITICAL FINDING: AS-REP Roasting vulnerable account discovered!`,
          `[+] Evidence captured and linked to Finding AD-FIND-002.`
        ]);
      } else {
        setLogs((prev) => [
          ...prev,
          `[*] Executing controlled security probe on authorized host...`,
          `[+] Target response validated. Active Directory object enumerated.`,
          `[*] SHA-256 evidence record: d41d8cd98f00b204e9800998ecf8427e`,
          `[+] Operation completed without error. [Exit: 0]`
        ]);
      }
      setIsRunning(false);
    }, 600);
  };

  const sampleCommands = [
    { label: 'Enumerate SPNs', cmd: 'GetUserSPNs.py adstrike.local/jdoe:Password123! -dc-ip 192.168.56.10 -request' },
    { label: 'Nmap Port Scan', cmd: 'nmap -sV -p 88,135,389,445 192.168.56.10' },
    { label: 'Audit PreAuth Users', cmd: "Get-ADUser -Filter 'DoesNotRequirePreAuth -eq $True'" },
  ];

  return (
    <div className={`rounded-lg border ${template.palette.border} ${template.palette.bgCard} p-4 text-xs font-mono flex flex-col justify-between`}>
      {/* Terminal Title Bar */}
      <div className="flex items-center justify-between pb-2.5 border-b border-neutral-800/80 mb-2.5">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 inline-block" />
          </div>
          <span className="font-bold text-neutral-200 text-xs ml-1 flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5 text-neutral-400" />
            OPERATIONAL ASSESSMENT CONSOLE
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950/70 border border-emerald-600/50 text-emerald-300 font-mono flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            STDOUT READY
          </span>
        </div>
      </div>

      {/* Quick Launch Command Palette */}
      <div className="flex flex-wrap gap-1.5 mb-2.5">
        {sampleCommands.map((item) => (
          <button
            key={item.label}
            onClick={() => runSimulatedCommand(item.cmd)}
            disabled={isRunning}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 text-[11px] font-mono cursor-pointer transition-colors"
          >
            <Play className="w-2.5 h-2.5 text-red-400" />
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      {/* Terminal Display Screen */}
      <div className="bg-neutral-950 rounded p-3 font-mono text-[11px] text-neutral-300 border border-neutral-900 min-h-[160px] max-h-[220px] overflow-y-auto space-y-1">
        {logs.map((line, idx) => {
          const isCmd = line.startsWith('$');
          const isCritical = line.includes('CRITICAL') || line.includes('[!]');
          const isSuccess = line.includes('[+]');
          const isNotice = line.includes('[*]');

          return (
            <div
              key={idx}
              className={`${
                isCmd
                  ? 'text-neutral-100 font-bold bg-neutral-900/60 px-1 py-0.5 rounded'
                  : isCritical
                  ? 'text-red-400 font-semibold'
                  : isSuccess
                  ? 'text-emerald-400'
                  : isNotice
                  ? 'text-neutral-400'
                  : 'text-neutral-300'
              }`}
            >
              {line}
            </div>
          );
        })}
        {isRunning && (
          <div className="flex items-center gap-2 text-amber-400 animate-pulse pt-1">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>Processing authorized command on lab target...</span>
          </div>
        )}
      </div>

      {/* Execution Status Footer */}
      <div className="mt-2 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[10px] text-neutral-400 font-mono">
        <div className="flex items-center gap-1.5">
          <Shield className="w-3 h-3 text-emerald-400" />
          <span>Output automatically hashed & stored in evidence repository</span>
        </div>
        <div className="flex items-center gap-1 text-neutral-300">
          <Clock className="w-3 h-3" />
          <span>Last probe: 0.34s</span>
        </div>
      </div>
    </div>
  );
};
