import React, { useState, useRef, useEffect } from 'react';
import {
  Terminal,
  Play,
  Copy,
  Check,
  RotateCcw,
  Sliders,
  Cpu,
  Shield,
  Layers,
  FileCode2,
  Database,
  Search,
  Eye,
  Hash,
  Activity
} from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface ProgrammerCmdWorkbenchProps {
  template: InterfaceTemplate;
}

interface TerminalEntry {
  command?: string;
  output: string | string[];
  type?: 'cmd' | 'stdout' | 'stderr' | 'success' | 'alert' | 'ascii';
  timestamp: string;
}

export const ProgrammerCmdWorkbench: React.FC<ProgrammerCmdWorkbenchProps> = ({ template }) => {
  const [activeSubTab, setActiveSubTab] = useState<'shell' | 'hex' | 'ldap' | 'ascii_map'>('shell');
  const [inputVal, setInputVal] = useState<string>('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [scanlinesActive, setScanlinesActive] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<'sm' | 'base'>('sm');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const initialEntries: TerminalEntry[] = [
    {
      timestamp: '12:40:01',
      type: 'ascii',
      output: [
        '  █████╗ ██████╗ ███████╗████████╗██████╗ ██╗██╗  ██╗███████╗',
        ' ██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██║██║ ██╔╝██╔════╝',
        ' ███████║██║  ██║███████╗   ██║   ██████╔╝██║█████╔╝ █████╗  ',
        ' ██╔══██║██║  ██║╚════██║   ██║   ██╔══██╗██║██╔═██╗ ██╔══╝  ',
        ' ██║  ██║██████╔╝███████║   ██║   ██║  ██║██║██║  ██╗███████╗',
        ' ╚═╝  ╚═╝╚═════╝ ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚══════╝',
        '   ADSTRIKE v1.0.0-LAB // ENTERPRISE ACTIVE DIRECTORY RED-TEAM TUI',
        '   [*] AUTHORIZED LAB TARGET SCOPE: 192.168.56.0/24'
      ]
    },
    {
      timestamp: '12:40:04',
      type: 'stdout',
      output: [
        '[*] Loading red-team security modules: [nmap, impacket, ldapsearch, kerberos, bloodhound]',
        '[*] Initializing target host allowlist: 192.168.56.10, 192.168.56.20, 192.168.56.30, 192.168.56.40',
        '[+] Scope enforcement engine active: Strict Out-of-Scope Blocking = TRUE',
        'Type "help" to display available commands or select from the preset execution buttons below.'
      ]
    },
    {
      timestamp: '12:41:10',
      command: 'nmap -sV -p 88,135,389,445 192.168.56.10',
      type: 'cmd',
      output: [
        'Starting Nmap 7.94 ( https://nmap.org ) at 2026-09-13 12:41 UTC',
        'Nmap scan report for DC01.adstrike.local (192.168.56.10)',
        'Host is up (0.00042s latency).',
        '',
        'PORT    STATE SERVICE      VERSION',
        '88/tcp  open  kerberos-sec Microsoft Windows Kerberos (server time: 2026-09-13 12:41:12Z)',
        '135/tcp open  msrpc        Microsoft Windows RPC',
        '389/tcp open  ldap         Microsoft Windows Active Directory LDAP (Domain: adstrike.local)',
        '445/tcp open  microsoft-ds Windows Server 2022 Standard SMB (smb2/3: enabled, signing: REQUIRED)',
        '',
        'Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows_server_2022',
        'Nmap done: 1 IP address (1 host up) scanned in 1.18 seconds'
      ]
    },
    {
      timestamp: '12:42:35',
      command: 'GetUserSPNs.py adstrike.local/jdoe:Password123! -dc-ip 192.168.56.10 -request',
      type: 'cmd',
      output: [
        'Impacket v0.12.0 - Copyright Fortra, LLC and its affiliated companies',
        '',
        'ServicePrincipalName               Name       MemberOf                               PasswordLastSet             LastLogon',
        '---------------------------------  ---------  -------------------------------------  --------------------------  --------------------------',
        'MSSQLSvc/WIN-SRV-01.adstrike.local svc_mssql  CN=SQLAdmins,CN=Users,DC=adstrike...  2026-03-14 09:12:44.821943  2026-09-12 18:22:01.129402',
        '',
        '[*] Querying Kerberos TGS ticket for user: svc_mssql...',
        '[+] Hash extracted: $krb5tgs$23$*svc_mssql*adstrike.local*MSSQLSvc/WIN-SRV-01.adstrike.local*$b471...c82a',
        '[!] ENCRYPTION CIPHER: RC4-HMAC (Vulnerable to offline dictionary attack)',
        '[*] Evidence auto-cataloged: /vault/evidence/T1558.003_svc_mssql.hash (SHA-256: 7f3b4c9...)'
      ]
    }
  ];

  const [entries, setEntries] = useState<TerminalEntry[]>(initialEntries);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [entries]);

  const executeCommand = async (cmdText: string) => {
    const trimmed = cmdText.trim();
    if (!trimmed) return;

    setCommandHistory((prev) => [...prev, trimmed]);
    setHistoryIndex(-1);

    const now = new Date();
    const ts = now.toTimeString().split(' ')[0];

    const lower = trimmed.toLowerCase();

    if (lower === 'clear' || lower === 'cls') {
      setEntries([]);
      setInputVal('');
      return;
    }

    setInputVal('');

    try {
      const response = await fetch('/api/terminal/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: trimmed }),
      });

      const data = await response.json();

      if (!response.ok || data.scopeBlocked) {
        setEntries((prev) => [
          ...prev,
          {
            timestamp: ts,
            command: trimmed,
            type: 'alert',
            output: [
              '------------------------------------------------------------------------',
              `[!] SCOPE ENFORCEMENT GUARD VIOLATION (HTTP 403 EPERM)`,
              `[!] ${data.error || 'Execution blocked by Scope Guard.'}`,
              '[*] Assessment rule: Only 192.168.56.0/24 targets are permitted.',
              '------------------------------------------------------------------------'
            ]
          }
        ]);
        return;
      }

      setEntries((prev) => [
        ...prev,
        {
          timestamp: data.timestamp || ts,
          command: trimmed,
          type: 'cmd',
          output: data.output || [`[*] Command executed: ${trimmed}`]
        }
      ]);
    } catch (err: any) {
      setEntries((prev) => [
        ...prev,
        {
          timestamp: ts,
          command: trimmed,
          type: 'alert',
          output: [`[!] Network or server connection error: ${err.message}`]
        }
      ]);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeCommand(inputVal);
    } else if (e.key === 'ArrowUp') {
      if (commandHistory.length > 0) {
        const nextIndex = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
        setHistoryIndex(nextIndex);
        setInputVal(commandHistory[nextIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      if (historyIndex !== -1) {
        const nextIndex = historyIndex + 1;
        if (nextIndex >= commandHistory.length) {
          setHistoryIndex(-1);
          setInputVal('');
        } else {
          setHistoryIndex(nextIndex);
          setInputVal(commandHistory[nextIndex]);
        }
      }
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 1500);
  };

  return (
    <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col font-mono text-xs overflow-hidden shadow-2xl relative`}>
      {/* Optional CRT Scanlines Filter */}
      {scanlinesActive && (
        <div
          className="absolute inset-0 pointer-events-none z-30 opacity-25"
          style={{
            background: 'linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.4) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.03), rgba(0, 255, 0, 0.01), rgba(0, 0, 255, 0.03))',
            backgroundSize: '100% 3px, 6px 100%'
          }}
        />
      )}

      {/* Top Programmer Tool Bar & Tmux Multi-Window Header */}
      <div className="bg-neutral-950 px-4 py-2 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 select-none">
        {/* Left: Window Tabs */}
        <div className="flex items-center gap-1">
          <div className="flex items-center gap-1.5 mr-3 pr-3 border-r border-neutral-800">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" />
            <span className="text-[11px] font-bold text-neutral-300 ml-1">operator@kali:~/adstrike</span>
          </div>

          {/* Sub-Tabs */}
          {[
            { id: 'shell', label: '1:zsh/cmd', icon: Terminal },
            { id: 'hex', label: '2:ticket-hex', icon: Hash },
            { id: 'ldap', label: '3:ldap-objects', icon: Database },
            { id: 'ascii_map', label: '4:ascii-graph', icon: Layers },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`px-2.5 py-1 rounded text-[11px] font-mono flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-neutral-800 text-neutral-100 font-bold border border-neutral-700'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
                }`}
              >
                <Icon className="w-3 h-3 text-red-400" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Right: Technical Display Controls */}
        <div className="flex items-center gap-2 text-[10px] text-neutral-400 font-mono">
          <button
            onClick={() => setScanlinesActive(!scanlinesActive)}
            className={`px-2 py-0.5 rounded border cursor-pointer ${
              scanlinesActive
                ? 'bg-amber-950 text-amber-300 border-amber-700'
                : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-neutral-200'
            }`}
          >
            CRT Scanlines: {scanlinesActive ? 'ON' : 'OFF'}
          </button>

          <button
            onClick={() => setFontSize(fontSize === 'sm' ? 'base' : 'sm')}
            className="px-2 py-0.5 rounded bg-neutral-900 text-neutral-300 border border-neutral-800 hover:text-white cursor-pointer"
          >
            Font: {fontSize.toUpperCase()}
          </button>

          <button
            onClick={() => setEntries([])}
            className="px-2 py-0.5 rounded bg-neutral-900 text-neutral-300 border border-neutral-800 hover:text-white cursor-pointer flex items-center gap-1"
          >
            <RotateCcw className="w-2.5 h-2.5" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* Quick Launch Command Palette */}
      <div className="bg-neutral-900/90 px-4 py-1.5 border-b border-neutral-800/80 flex items-center gap-2 overflow-x-auto text-[10px] text-neutral-400 select-none">
        <span className="font-bold text-neutral-300 uppercase tracking-wider flex-shrink-0">PRESET CLI:</span>
        {[
          { label: 'scope', cmd: 'scope' },
          { label: 'targets', cmd: 'targets' },
          { label: 'nmap DC01', cmd: 'nmap -sV -p 88,135,389,445 192.168.56.10' },
          { label: 'GetUserSPNs (TGS)', cmd: 'GetUserSPNs.py adstrike.local/jdoe:Password123! -dc-ip 192.168.56.10 -request' },
          { label: 'secretsdump (DCSync)', cmd: 'secretsdump.py adstrike.local/administrator@192.168.56.10' },
          { label: 'bloodhound-python', cmd: 'bloodhound-python -d adstrike.local -u jdoe -p Password123! -c all' },
        ].map((btn) => (
          <button
            key={btn.label}
            onClick={() => executeCommand(btn.cmd)}
            className="px-2 py-0.5 rounded bg-neutral-950 hover:bg-neutral-800 text-neutral-300 border border-neutral-800 hover:border-neutral-700 whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1"
          >
            <Play className="w-2 h-2 text-red-400" />
            <span>{btn.label}</span>
          </button>
        ))}
      </div>

      {/* Main Terminal Screen */}
      <div
        className={`bg-neutral-950 text-neutral-200 p-4 min-h-[380px] max-h-[520px] overflow-y-auto space-y-2 select-text ${
          fontSize === 'base' ? 'text-xs md:text-sm' : 'text-xs'
        }`}
        onClick={() => inputRef.current?.focus()}
      >
        {activeSubTab === 'shell' && (
          <>
            {entries.map((item, idx) => (
              <div key={idx} className="group relative">
                {item.command && (
                  <div className="flex items-center gap-2 text-neutral-100 font-bold mb-1">
                    <span className="text-cyan-400 select-none">┌──(operator㉿adstrike)-[~/recon]</span>
                  </div>
                )}

                {item.command && (
                  <div className="flex items-center gap-2 text-neutral-100 font-bold mb-1.5 pl-2">
                    <span className="text-cyan-400 select-none">└─$</span>
                    <span className="text-white bg-neutral-900/60 px-1.5 py-0.5 rounded border border-neutral-800">
                      {item.command}
                    </span>
                    <span className="text-[10px] text-neutral-400 font-mono select-none ml-auto">
                      [{item.timestamp}]
                    </span>
                  </div>
                )}

                {/* Output Lines */}
                <div
                  className={`pl-2 font-mono ${
                    item.type === 'ascii'
                      ? 'text-red-400 leading-tight'
                      : item.type === 'alert'
                      ? 'text-amber-300'
                      : 'text-neutral-300'
                  }`}
                >
                  {Array.isArray(item.output) ? (
                    item.output.map((line, lIdx) => {
                      const isAlert = line.includes('[!]') || line.includes('CRITICAL');
                      const isSuccess = line.includes('[+]');
                      const isNotice = line.includes('[*]');
                      const isBorder = line.startsWith('+--') || line.startsWith('┌─') || line.startsWith('└─') || line.startsWith('├─');

                      return (
                        <div
                          key={lIdx}
                          className={`${
                            isAlert
                              ? 'text-red-400 font-semibold'
                              : isSuccess
                              ? 'text-emerald-400'
                              : isNotice
                              ? 'text-neutral-400'
                              : isBorder
                              ? 'text-neutral-400'
                              : ''
                          }`}
                        >
                          {line}
                        </div>
                      );
                    })
                  ) : (
                    <div>{item.output}</div>
                  )}
                </div>
              </div>
            ))}

            {/* Interactive Prompt Input Row */}
            <div className="pt-2">
              <div className="text-cyan-400 select-none font-bold text-xs">
                ┌──(operator㉿adstrike)-[~/recon]
              </div>
              <div className="flex items-center gap-2 pl-2">
                <span className="text-cyan-400 select-none font-bold text-xs">└─$</span>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="type command (e.g. nmap, GetUserSPNs.py, targets, help)..."
                  className="flex-1 bg-transparent text-neutral-100 font-mono text-xs focus:outline-none placeholder:text-neutral-400 caret-red-400"
                  autoFocus
                />
                <button
                  onClick={() => executeCommand(inputVal)}
                  className="px-2 py-0.5 rounded bg-red-700 hover:bg-red-600 text-white text-[10px] font-mono cursor-pointer"
                >
                  EXEC
                </button>
              </div>
            </div>

            <div ref={terminalEndRef} />
          </>
        )}

        {/* Tab 2: Raw Ticket & Hex Dump Inspector */}
        {activeSubTab === 'hex' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800 text-neutral-400 text-[11px]">
              <span>ARTIFACT: /vault/evidence/T1558.003_svc_mssql.hash [KERBEROS TGS TICKET]</span>
              <span className="text-emerald-400">CIPHER: RC4-HMAC (type 23)</span>
            </div>

            <div className="bg-neutral-900/80 p-3 rounded border border-neutral-800 text-[11px] leading-relaxed">
              <div className="text-neutral-400 font-bold mb-1">RAW EXTRACTED TGS TICKET STRUCTURE (ASN.1):</div>
              <div className="text-neutral-300 break-all select-all font-mono">
                $krb5tgs$23$*svc_mssql*adstrike.local*MSSQLSvc/WIN-SRV-01.adstrike.local*$b4718c99e2b10a4f5c9e2b10a4f5c9e2$d92a01f8c7b41e3d5a6c8e9b0a1f2d3e4c5b6a7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c
              </div>
            </div>

            <div className="text-neutral-400 font-bold text-[11px]">HEXADECIMAL MEMORY DUMP:</div>
            <pre className="text-[11px] text-neutral-400 bg-neutral-900/60 p-3 rounded border border-neutral-850 overflow-x-auto">
{`00000000  6e 82 04 2a 30 82 04 26  a0 03 02 01 05 a1 0e 1b  |n..*0..&........|
00000010  0c 41 44 53 54 52 49 4b  45 2e 4c 4f 43 41 4c a2  |.ADSTRIKE.LOCAL.|
00000020  31 30 2f a0 03 02 01 02  a1 28 30 26 1b 08 4d 53  |10/......(0&..MS|
00000030  53 51 4c 53 76 63 1b 1a  57 49 4e 2d 53 52 56 2d  |SQLSvc..WIN-SRV-|
00000040  30 31 2e 61 64 73 74 72  69 6b 65 2e 6c 6f 63 61  |01.adstrike.loca|
00000050  6c a3 82 03 d9 30 82 03  d5 a0 03 02 01 17 a1 03  |l....0..........|
00000060  02 01 02 a2 82 03 c7 04  82 03 c3 b4 71 8c 99 e2  |............q...|`}
            </pre>
          </div>
        )}

        {/* Tab 3: LDAP Object Explorer */}
        {activeSubTab === 'ldap' && (
          <div className="space-y-3">
            <div className="text-neutral-400 text-[11px] pb-2 border-b border-neutral-800 flex justify-between">
              <span>LDAP OBJECT TREE // BASE: DC=adstrike,DC=local</span>
              <span className="text-cyan-400">BIND: jdoe@adstrike.local</span>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="font-bold text-neutral-200">dn: CN=svc_mssql,OU=Service Accounts,DC=adstrike,DC=local</div>
                <div className="text-neutral-400">objectClass: top, person, organizationalPerson, user</div>
                <div className="text-neutral-400">sAMAccountName: svc_mssql</div>
                <div className="text-red-400 font-bold">servicePrincipalName: MSSQLSvc/WIN-SRV-01.adstrike.local:1433</div>
                <div className="text-neutral-400">userAccountControl: 512 (NORMAL_ACCOUNT)</div>
                <div className="text-neutral-400">memberOf: CN=SQLAdmins,CN=Users,DC=adstrike,DC=local</div>
              </div>

              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="font-bold text-neutral-200">dn: CN=backup_operator,CN=Users,DC=adstrike,DC=local</div>
                <div className="text-neutral-400">objectClass: top, person, organizationalPerson, user</div>
                <div className="text-neutral-400">sAMAccountName: backup_operator</div>
                <div className="text-red-400 font-bold">userAccountControl: 4194816 (DONT_REQ_PREAUTH | NORMAL_ACCOUNT)</div>
                <div className="text-amber-400">riskAssessment: AS-REP Roasting Vulnerability (MITRE T1558.004)</div>
              </div>

              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <div className="font-bold text-neutral-200">dn: CN=WIN-SRV-01,OU=Servers,DC=adstrike,DC=local</div>
                <div className="text-neutral-400">objectClass: top, person, organizationalPerson, user, computer</div>
                <div className="text-neutral-400">sAMAccountName: WIN-SRV-01$</div>
                <div className="text-red-400 font-bold">userAccountControl: 528384 (TRUSTED_FOR_DELEGATION | WORKSTATION_TRUST)</div>
                <div className="text-amber-400">riskAssessment: Unconstrained Kerberos Delegation Configured</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: ASCII Attack Graph Map */}
        {activeSubTab === 'ascii_map' && (
          <div className="space-y-3">
            <div className="text-neutral-400 text-[11px] pb-2 border-b border-neutral-800">
              ASCII ATTACK PATH TOPOLOGY // CALCULATED PIVOT CHAIN TO DOMAIN ADMIN
            </div>

            <pre className="text-xs text-neutral-200 bg-neutral-900/90 p-4 rounded border border-neutral-850 overflow-x-auto leading-relaxed">
{`+-----------------------+
|  [USER] jdoe          |  <-- Initial Footprint (Compromised Credential)
|  Helpdesk Staff       |
+-----------------------+
           |
           | (Local Logon)
           v
+-----------------------+
|  [HOST] WIN10-01      |  (192.168.56.20)
|  Windows 10 Pro 22H2  |  - SMB Signing Disabled
+-----------------------+
           |
           | [T1558.003] Request TGS for SPN
           v
+-----------------------+
|  [SPN] svc_mssql      |  MSSQLSvc/WIN-SRV-01.adstrike.local:1433
|  RC4-HMAC Cipher      |  <-- Cracked to plain-text password
+-----------------------+
           |
           | [T1021.002] Admin Access (Pass-the-Hash / Reuse)
           v
+-----------------------+
|  [SRV] WIN-SRV-01     |  (192.168.56.30) Member Server
|  TRUSTED_FOR_DELEG.   |  <-- Unconstrained Kerberos Delegation
+-----------------------+
           |
           | [T1558.001] Extract Domain Admin TGT from LSASS
           v
+-----------------------+
|  [GROUP] Domain Admins|
+-----------------------+
           |
           | Full Replicating Directory Changes (DCSync)
           v
+-----------------------+
|  [DC] DC01            |  (192.168.56.10) Primary Domain Controller
|  adstrike.local       |  STATUS: FULL LAB DOMAIN COMPROMISE
+-----------------------+`}
            </pre>
          </div>
        )}
      </div>

      {/* Tmux Bottom Status Bar */}
      <div className="bg-neutral-900 border-t border-neutral-800 px-3 py-1 flex items-center justify-between text-[11px] font-mono text-neutral-400 select-none">
        <div className="flex items-center gap-2">
          <span className="px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800 text-[10px]">
            TMUX: 0
          </span>
          <span className="text-neutral-300 font-semibold">[0:zsh* 1:impacket 2:bloodhound 3:secretsdump]</span>
          <span className="hidden sm:inline text-neutral-600">|</span>
          <span className="hidden sm:inline text-emerald-400">LAB SCOPE: 192.168.56.0/24</span>
        </div>

        <div className="flex items-center gap-3 text-[10px]">
          <span>CPU: 4%</span>
          <span>MEM: 284MB</span>
          <span className="text-neutral-300 font-bold">12:43:21 UTC</span>
        </div>
      </div>
    </div>
  );
};
