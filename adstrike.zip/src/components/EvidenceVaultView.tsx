import React, { useState, useEffect } from 'react';
import {
  FileCheck2,
  Copy,
  Check,
  Hash,
  ShieldAlert,
  ShieldCheck,
  Download,
  Key,
  Database,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { InterfaceTemplate, EvidenceArtifact } from '../types';

interface EvidenceVaultViewProps {
  template: InterfaceTemplate;
}

export const EvidenceVaultView: React.FC<EvidenceVaultViewProps> = ({ template }) => {
  const [evidenceList, setEvidenceList] = useState<EvidenceArtifact[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedArtifact, setSelectedArtifact] = useState<EvidenceArtifact | null>(null);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [verifyingHash, setVerifyingHash] = useState(false);
  const [verifyResult, setVerifyResult] = useState<{ match: boolean; computedHash: string } | null>(null);

  useEffect(() => {
    fetch('/api/evidence')
      .then((res) => res.json())
      .then((data) => {
        setEvidenceList(data);
        if (data.length > 0) setSelectedArtifact(data[0]);
      })
      .catch((err) => console.error('Failed to load evidence:', err));
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const verifyChecksumLive = async (artifact: EvidenceArtifact) => {
    setVerifyingHash(true);
    setVerifyResult(null);

    try {
      const msgBuffer = new TextEncoder().encode(artifact.rawPreview);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');

      // Compare lowercase
      const isMatch = hashHex.toLowerCase() === artifact.sha256.toLowerCase();
      setVerifyResult({ match: isMatch, computedHash: hashHex });
    } catch (e) {
      console.error('Crypto error:', e);
    } finally {
      setVerifyingHash(false);
    }
  };

  const exportEvidenceJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(evidenceList, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `adstrike-evidence-chain-of-custody-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const filteredEvidence = evidenceList.filter((ev) => {
    if (filterType === 'ALL') return true;
    return ev.payloadType === filterType;
  });

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Header Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-red-950 text-red-400 border border-red-800">
            <FileCheck2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100">
                CRYPTOGRAPHIC EVIDENCE VAULT (CHAIN-OF-CUSTODY)
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
                {evidenceList.length} ARTIFACTS
              </span>
            </div>
            <p className="text-neutral-400 text-xs mt-0.5">
              All artifacts are recorded with SHA-256 cryptographic hashes and operator signatures for proof-of-concept auditability.
            </p>
          </div>
        </div>

        {/* Filter Chips & Export Button */}
        <div className="flex items-center gap-2">
          {['ALL', 'hash', 'ntds_dit'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-2.5 py-1 rounded text-[11px] cursor-pointer transition-colors ${
                filterType === type
                  ? 'bg-neutral-800 text-neutral-100 font-bold border border-neutral-600'
                  : 'bg-neutral-950 text-neutral-400 hover:text-neutral-200 border border-neutral-900'
              }`}
            >
              {type.toUpperCase()}
            </button>
          ))}

          <button
            onClick={exportEvidenceJSON}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-neutral-850 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 cursor-pointer text-xs"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Artifact List & Deep Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Artifact Cards List (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          {filteredEvidence.map((art) => {
            const isSelected = selectedArtifact?.id === art.id;
            return (
              <div
                key={art.id}
                onClick={() => {
                  setSelectedArtifact(art);
                  setVerifyResult(null);
                }}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  isSelected
                    ? `${template.palette.bgCard} border-red-500/70 shadow-lg ring-1 ring-red-500/30`
                    : 'bg-neutral-950/70 border-neutral-800/80 hover:border-neutral-700 hover:bg-neutral-900/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800">
                      {art.mitreId}
                    </span>
                    <span className="font-bold text-neutral-200">{art.technique}</span>
                  </div>
                  <span className="text-[10px] text-neutral-400">{art.timestamp.split(' ')[1]}</span>
                </div>

                <div className="text-[11px] text-neutral-400 flex items-center justify-between mt-1">
                  <span>Host: <strong className="text-neutral-300">{art.targetHost}</strong></span>
                  <span className="text-neutral-400">{art.sourceTool}</span>
                </div>

                <div className="mt-2 text-[10px] font-mono text-neutral-400 bg-neutral-950 px-2 py-1 rounded border border-neutral-900 truncate flex items-center justify-between">
                  <span className="truncate">SHA256: {art.sha256}</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-neutral-900 text-neutral-400 flex-shrink-0">
                    {art.executionMode || 'SIMULATED'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Deep Artifact Inspector & Proof Preview (7 Cols) */}
        <div className="lg:col-span-7">
          {selectedArtifact ? (
            <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-4 shadow-xl`}>
              <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800">
                      {selectedArtifact.mitreId}
                    </span>
                    <h3 className="text-sm font-bold text-neutral-100">
                      {selectedArtifact.technique}
                    </h3>
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">
                    Captured from {selectedArtifact.targetHost} via {selectedArtifact.sourceTool}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => verifyChecksumLive(selectedArtifact)}
                    disabled={verifyingHash}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800 cursor-pointer text-xs disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${verifyingHash ? 'animate-spin' : ''}`} />
                    <span>Verify Live SHA-256</span>
                  </button>

                  <button
                    onClick={() => handleCopy(selectedArtifact.rawPreview, selectedArtifact.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 cursor-pointer text-xs"
                  >
                    {copiedId === selectedArtifact.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Payload</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Cryptographic Integrity Hash & Live Verification Status */}
              <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-850 space-y-1.5">
                <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider flex items-center justify-between">
                  <span>RECORDED CHECKSUM (SHA-256)</span>
                  <span className="text-neutral-400">SIGNING: {selectedArtifact.operator}</span>
                </div>
                <div className="text-xs font-mono text-cyan-300 break-all select-all">
                  {selectedArtifact.sha256}
                </div>

                {verifyResult && (
                  <div className={`p-2 rounded mt-2 text-[11px] font-bold flex items-center gap-2 ${
                    verifyResult.match
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700'
                      : 'bg-red-950/80 text-red-300 border border-red-700'
                  }`}>
                    {verifyResult.match ? (
                      <>
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        <span>INTEGRITY VERIFIED: Client WebCrypto computed exact match. Payload is 100% untampered.</span>
                      </>
                    ) : (
                      <>
                        <ShieldAlert className="w-4 h-4 text-red-400" />
                        <span>INTEGRITY MISMATCH: Computed hash differs from recorded artifact checksum.</span>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Raw Captured Payload / Ticket Text */}
              <div className="space-y-1.5">
                <div className="text-xs font-bold text-neutral-300 flex items-center justify-between">
                  <span>RAW ARTIFACT PAYLOAD / HASH:</span>
                  <span className="text-[10px] text-neutral-400 uppercase">
                    TYPE: {selectedArtifact.payloadType}
                  </span>
                </div>
                <pre className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 overflow-x-auto whitespace-pre-wrap font-mono leading-relaxed select-all">
                  {selectedArtifact.rawPreview}
                </pre>
              </div>

              {/* Technical Context Explanation */}
              <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-400 leading-relaxed">
                <strong className="text-neutral-200">Replication &amp; Impact Analysis:</strong> This cryptographic artifact provides irrefutable evidence of credential extraction during the authorized simulation. It confirms vulnerability to offline cracking or DRSUAPI replication rights without requiring permanent modification to directory schemas.
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-neutral-400 border border-neutral-800 rounded-xl">
              Select an evidence artifact on the left to inspect cryptographic hashes.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
