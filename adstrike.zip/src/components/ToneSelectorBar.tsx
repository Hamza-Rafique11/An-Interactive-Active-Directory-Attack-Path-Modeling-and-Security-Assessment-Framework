import React, { useState } from 'react';
import { Palette, CheckCircle2, Eye, Sparkles, Layers, Terminal, Shield, Monitor } from 'lucide-react';
import { InterfaceTemplate, InterfaceToneId } from '../types';

interface ToneSelectorBarProps {
  templates: InterfaceTemplate[];
  selectedToneId: InterfaceToneId;
  onSelectTone: (id: InterfaceToneId) => void;
  confirmedToneId: InterfaceToneId | null;
  onConfirmTone: (id: InterfaceToneId) => void;
  onToggleTerminalMode?: () => void;
  isTerminalMode?: boolean;
}

export const ToneSelectorBar: React.FC<ToneSelectorBarProps> = ({
  templates,
  selectedToneId,
  onSelectTone,
  confirmedToneId,
  onConfirmTone,
  onToggleTerminalMode,
  isTerminalMode
}) => {
  const [filterCategory, setFilterCategory] = useState<'all' | 'cmd' | 'soc'>('all');

  const currentTemplate = templates.find((t) => t.id === selectedToneId) || templates[0];

  const filteredTemplates = templates.filter((tpl) => {
    if (filterCategory === 'cmd') {
      return ['kali-zsh-console', 'cobalt-beacon-cmd', 'retro-amber-crt', 'bloodhound-cypher-cli', 'matrix-terminal'].includes(tpl.id);
    }
    if (filterCategory === 'soc') {
      return ['tactical-red', 'modern-soc', 'precision-indigo'].includes(tpl.id);
    }
    return true;
  });

  const getSwatchColors = (id: InterfaceToneId) => {
    switch (id) {
      case 'kali-zsh-console':
        return { canvas: '#0d1117', p1: '#1f6feb', p2: '#58a6ff' };
      case 'cobalt-beacon-cmd':
        return { canvas: '#0a0a0f', p1: '#b91c1c', p2: '#ef4444' };
      case 'retro-amber-crt':
        return { canvas: '#070400', p1: '#ffb000', p2: '#cc8800' };
      case 'bloodhound-cypher-cli':
        return { canvas: '#080d14', p1: '#0284c7', p2: '#38bdf8' };
      case 'tactical-red':
        return { canvas: '#090b10', p1: '#ef4444', p2: '#f59e0b' };
      case 'matrix-terminal':
        return { canvas: '#040608', p1: '#10b981', p2: '#22c55e' };
      case 'modern-soc':
        return { canvas: '#0b1120', p1: '#06b6d4', p2: '#38bdf8' };
      case 'precision-indigo':
        return { canvas: '#080c16', p1: '#6366f1', p2: '#a855f7' };
      default:
        return { canvas: '#090b10', p1: '#ef4444', p2: '#f59e0b' };
    }
  };

  return (
    <section className="w-full bg-neutral-950/95 border-b border-neutral-800 px-4 py-3 select-none">
      <div className="max-w-7xl mx-auto space-y-3">
        {/* Banner Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded bg-neutral-900 border border-neutral-800 text-red-400">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-neutral-100 flex items-center gap-2 font-mono">
                <span>INTERFACE DESIGN TEMPLATES & COMMAND CONSOLES</span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800">
                  {templates.length} Archetypes Available
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Switch between authentic offensive programmer terminals (Kali ZSH, Cobalt Beacon, Amber CRT, BloodHound Cypher) and operational dashboards.
              </p>
            </div>
          </div>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            {onToggleTerminalMode && (
              <button
                onClick={onToggleTerminalMode}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-bold transition-all cursor-pointer ${
                  isTerminalMode
                    ? 'bg-amber-600 text-neutral-950 shadow-sm ring-1 ring-amber-400'
                    : 'bg-neutral-900 text-neutral-300 border border-neutral-700 hover:text-white hover:bg-neutral-850'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>{isTerminalMode ? 'View Full Dashboard' : 'Dedicated CMD Workbench'}</span>
              </button>
            )}

            {confirmedToneId ? (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-emerald-950/80 border border-emerald-500/70 text-emerald-300 font-mono text-xs">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Selected: <strong>{templates.find(t => t.id === confirmedToneId)?.name}</strong></span>
              </div>
            ) : (
              <button
                onClick={() => onConfirmTone(selectedToneId)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-sm transition-all cursor-pointer font-mono"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Confirm Selected Tone</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter Category Chips */}
        <div className="flex items-center gap-2 pt-1 border-t border-neutral-900 overflow-x-auto text-[11px] font-mono">
          <span className="text-neutral-400 font-bold uppercase tracking-wider text-[10px] mr-1">Filter Style:</span>
          {[
            { id: 'all', label: `All Archetypes (${templates.length})`, icon: Layers },
            { id: 'cmd', label: 'Programmer & CMD Interfaces (5)', icon: Terminal },
            { id: 'soc', label: 'SOC & Visual Dashboards (3)', icon: Monitor },
          ].map((cat) => {
            const Icon = cat.icon;
            const isCatActive = filterCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setFilterCategory(cat.id as any)}
                className={`px-2.5 py-1 rounded text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  isCatActive
                    ? 'bg-neutral-800 text-neutral-100 font-bold border border-neutral-700'
                    : 'bg-neutral-950 text-neutral-400 hover:text-neutral-200 border border-neutral-900'
                }`}
              >
                <Icon className="w-3 h-3 text-red-400" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {filteredTemplates.map((tpl) => {
            const isSelected = tpl.id === selectedToneId;
            const isConfirmed = tpl.id === confirmedToneId;
            const swatch = getSwatchColors(tpl.id);
            const isCmdStyle = ['kali-zsh-console', 'cobalt-beacon-cmd', 'retro-amber-crt', 'bloodhound-cypher-cli', 'matrix-terminal'].includes(tpl.id);

            return (
              <button
                key={tpl.id}
                onClick={() => onSelectTone(tpl.id)}
                className={`text-left p-3 rounded-lg border transition-all relative flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'border-neutral-200 bg-neutral-900 shadow-lg ring-1 ring-neutral-400/50'
                    : 'border-neutral-800/80 bg-neutral-950/70 hover:border-neutral-700 hover:bg-neutral-900/50'
                }`}
              >
                {/* Active Indicator Pin */}
                {isSelected && (
                  <span className="absolute top-2 right-2 flex items-center gap-1 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-950">
                    <Eye className="w-3 h-3 text-red-600" /> ACTIVE
                  </span>
                )}

                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-400">
                      {tpl.category}
                    </span>
                    {isCmdStyle && (
                      <span className="text-[9px] font-mono px-1 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
                        CMD/CLI
                      </span>
                    )}
                  </div>

                  <h3 className="text-xs font-bold text-neutral-100 mb-0.5 font-mono">
                    {tpl.name}
                  </h3>

                  <p className="text-[11px] text-neutral-400 leading-snug line-clamp-2 mb-2.5">
                    {tpl.tagline}
                  </p>
                </div>

                {/* Color Palette Preview Swatches */}
                <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-neutral-700"
                      style={{ backgroundColor: swatch.canvas }}
                      title="Base Canvas Tone"
                    />
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-neutral-700"
                      style={{ backgroundColor: swatch.p1 }}
                      title="Primary Accent"
                    />
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-neutral-700"
                      style={{ backgroundColor: swatch.p2 }}
                      title="Secondary Accent"
                    />
                  </div>

                  <span className="text-[10px] font-mono text-neutral-400">
                    {tpl.typography.displayFont}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Tone Detailed Spec Banner */}
        <div className="p-2.5 rounded bg-neutral-900/60 border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span className="text-neutral-300 text-xs">
              <strong className="text-neutral-100 font-mono">{currentTemplate.name}:</strong> {currentTemplate.description}
            </span>
          </div>

          <div className="flex items-center gap-3 text-neutral-400 font-mono text-[11px] self-end md:self-auto flex-shrink-0">
            <span>Font: <strong className="text-neutral-200">{currentTemplate.typography.monoFont}</strong></span>
            <span className="hidden lg:inline text-neutral-600">•</span>
            <span className="hidden lg:inline text-neutral-300">Audience: {currentTemplate.recommendedFor}</span>
          </div>
        </div>
      </div>
    </section>
  );
};

