import React, { useState, useEffect } from 'react';
import {
  GitFork,
  Terminal,
  ShieldAlert,
  ShieldCheck,
  Play,
  CheckCircle2,
  Lock,
  ArrowRight,
  Laptop,
  Server,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { InterfaceTemplate, ExecutionMode } from '../types';

interface LateralMovementViewProps {
  template: InterfaceTemplate;
}

export const LateralMovementView: React.FC<LateralMovementViewProps> = ({
  template,
}) => {
  const [selectedTarget, setSelectedTarget] = useState('192.168.56.20');
  const [execMethod, setExecMethod] = useState<'wmiexec' | 'psexec' | 'smbclient'>('wmiexec');
  const [command, setCommand] = useState('whoami /all');
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('AUTO');
  const [loading, setLoading] = useState(false);
  const [terminalOutput, setTerminalOutput] = useState<string[] | null>(null);
  const [scopeError, setScopeError] = useState<string | null>(null);
  const [lastMode, setLastMode] = useState<string | null>(null);

  const handleExecute = async () => {
    setLoading(true);
    setScopeError(null);
    setTerminalOutput(null);

    try {
      const res = await fetch('/api/lateral/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetIp: selectedTarget,
          method: execMethod,
          command,
          executionMode
        })
      });

      const data = await res.json();

      if (res.status === 403) {
        setScopeError(data.message || data.error || 'TARGET OUT OF SCOPE');
      } else if (res.ok) {
        setTerminalOutput(data.output || []);
        setLastMode(data.executionMode || 'SIMULATED');
      } else {
        setScopeError(data.error || 'Execution failed');
      }
    } catch (err: any) {
      setScopeError(`Execution error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Scope Warning */}
      {scopeError && (
        <div className="p-3.5 rounded-xl bg-red-950/90 border border-red-800 text-red-300 flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <span className="font-bold block">SCOPE GUARD PREVENTED OPERATION:</span>
              <span className="text-[11px] text-red-300">{scopeError}</span>
            </div>
          </div>
          <button
            onClick={() => {
              setSelectedTarget('192.168.56.20');
              setScopeError(null);
            }}
            className="px-2.5 py-1 rounded bg-red-900/80 hover:bg-red-800 text-white text-[10px] font-bold border border-red-700 cursor-pointer"
          >
            Reset Target
          </button>
        </div>
      )}

      {/* Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-2`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded bg-purple-950/80 border border-purple-800/60 text-purple-400">
              <GitFork className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
                  LATERAL MOVEMENT &amp; REMOTE PROTOCOL EXECUTION
                </h3>
                {lastMode && (
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    lastMode === 'REAL'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                      : 'bg-amber-950 text-amber-300 border border-amber-700'
                  }`}>
                    {lastMode === 'REAL' ? '🟢 REAL LAB EXECUTION' : '🟡 DEMO / SIMULATION'}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-neutral-400">
                Validating Pass-the-Hash, SMB signing posture, and WMI / RPC service creation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-700 rounded px-2 py-1">
              <span className="text-[10px] text-neutral-400">Mode:</span>
              <select
                value={executionMode}
                onChange={(e) => setExecutionMode(e.target.value as ExecutionMode)}
                className="bg-transparent text-purple-400 font-bold outline-none cursor-pointer text-xs"
              >
                <option value="AUTO">AUTO (Real Impacket + Fallback)</option>
                <option value="REAL">REAL ONLY (Impacket CLI)</option>
                <option value="SIMULATED">SIMULATED (Offline Lab Matrix)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Execution Workbench */}
        <div className={`lg:col-span-2 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-4 shadow-xl`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <h4 className="font-bold text-neutral-200 text-xs flex items-center gap-2">
              <Terminal className="w-4 h-4 text-purple-400" />
              <span>PASS-THE-HASH &amp; REMOTE WMI EXECUTION (IMPACKET)</span>
            </h4>
            <span className="px-2 py-0.5 rounded bg-neutral-800 text-[10px] text-purple-400 font-bold">
              MITRE T1021.002
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-neutral-400 block mb-1">Target Host IP:</label>
              <input
                type="text"
                value={selectedTarget}
                onChange={(e) => setSelectedTarget(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-neutral-200 font-mono outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-neutral-400 block mb-1">Execution Mechanism:</label>
              <select
                value={execMethod}
                onChange={(e) => setExecMethod(e.target.value as any)}
                className="w-full bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-xs text-neutral-200 outline-none"
              >
                <option value="wmiexec">wmiexec.py (DCOM / WMI over RPC)</option>
                <option value="psexec">psexec.py (SMB Named Pipe Service)</option>
                <option value="smbclient">smbclient.py (Direct Share Access)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] text-neutral-400 block mb-1">Command to Execute on Target:</label>
            <input
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-2 text-xs text-neutral-100 font-mono outline-none"
            />
          </div>

          <div className="p-3 rounded bg-neutral-950 border border-neutral-850 space-y-1 text-[10px] text-neutral-400">
            <span className="font-bold text-neutral-200 block">Credential &amp; Safety Context:</span>
            <div>Authentication: <span className="text-purple-400 font-bold">Pass-the-Hash (NTLM: 10b27e8a93e5e54c87c4a06d88f6a654)</span></div>
            <div>Identity: <span className="text-neutral-200">ADSTRIKE\Administrator</span></div>
            <div className="text-neutral-400 pt-1 border-t border-neutral-900">
              * In sandbox container environments without local Windows VMs, execution falls back gracefully to deterministic simulated telemetry without throwing fatal errors.
            </div>
          </div>

          <button
            onClick={handleExecute}
            disabled={loading}
            className="w-full py-2 rounded bg-purple-800 hover:bg-purple-700 disabled:opacity-50 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-colors"
          >
            <Play className={`w-4 h-4 fill-current ${loading ? 'animate-pulse' : ''}`} />
            <span>{loading ? 'EXECUTING OVER RPC/SMB...' : 'DISPATCH LATERAL COMMAND'}</span>
          </button>

          {/* Terminal Console Output */}
          {terminalOutput && (
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2 text-[11px] font-mono">
              <div className="flex items-center justify-between text-[10px] text-neutral-400 pb-1 border-b border-neutral-850">
                <span>STDOUT // LATERAL MOVEMENT CONSOLE</span>
                <span className="text-emerald-400 font-bold">EXIT: 0</span>
              </div>
              <pre className="overflow-x-auto text-neutral-300 leading-relaxed max-h-56 overflow-y-auto">
                {terminalOutput.join('\n')}
              </pre>
            </div>
          )}
        </div>

        {/* Right Col: SMB Signing Analysis Card */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-3 shadow-xl`}>
          <div className="flex items-center gap-2 pb-2 border-b border-neutral-800">
            <ShieldAlert className="w-4 h-4 text-red-400" />
            <h4 className="font-bold text-neutral-200 text-xs">
              SMB SIGNING RELAY VULNERABILITY
            </h4>
          </div>

          <div className="p-3 rounded bg-neutral-950 border border-red-950/80 space-y-2 text-[10px]">
            <div className="text-red-400 font-bold flex items-center gap-1">
              <span>WIN10-01.adstrike.local:445</span>
            </div>
            <p className="text-neutral-400 leading-relaxed">
              SMB signing is <strong className="text-red-300">disabled / not required</strong> on non-Domain Controller workstations.
            </p>
            <div className="p-2 rounded bg-red-950/50 border border-red-900/60 text-neutral-300">
              <strong>Relay Attack Path:</strong>
              <p className="mt-1 text-neutral-400">
                Poisoning LLMNR/NBT-NS via Responder allows capturing NetNTLMv2 authentication and relaying it directly to WIN10-01 with ntlmrelayx, granting an automatic administrative interactive session.
              </p>
            </div>
          </div>

          <div className="space-y-1.5 text-[10px] text-neutral-400">
            <span className="font-bold text-neutral-200 block">HARDENING GPO:</span>
            <p>Computer Configuration -&gt; Windows Settings -&gt; Security Settings -&gt; Local Policies -&gt; Security Options</p>
            <div className="p-2 rounded bg-neutral-950 text-emerald-400 font-bold">
              Microsoft network server: Digitally sign communications (always) = ENABLED
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
