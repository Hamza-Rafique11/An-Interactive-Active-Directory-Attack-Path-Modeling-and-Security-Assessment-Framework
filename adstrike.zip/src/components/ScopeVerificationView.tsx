import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Lock,
  Server,
  FileCheck,
  Send,
  Edit3,
  Save,
  RotateCcw
} from 'lucide-react';
import { InterfaceTemplate, LabScopeConfig } from '../types';

interface ScopeVerificationViewProps {
  template: InterfaceTemplate;
  onScopeUpdated?: (newCidr: string) => void;
}

export const ScopeVerificationView: React.FC<ScopeVerificationViewProps> = ({ template, onScopeUpdated }) => {
  const [scopeConfig, setScopeConfig] = useState<LabScopeConfig>({
    assessmentName: 'ADStrike Active Directory Red-Team Authorized Lab Assessment',
    authorizedCidr: '192.168.56.0/24',
    subnetMask: '255.255.255.0',
    networkAddress: '192.168.56.0',
    broadcastAddress: '192.168.56.255',
    allowedHosts: [
      '192.168.56.10',
      '192.168.56.20',
      '192.168.56.30',
      '192.168.56.40',
      '192.168.56.50',
    ],
    operatorSignature: 'SEC-OPS-KALI-VERIFIED-LAB-ONLY',
    strictBlocking: true,
    rulesOfEngagement: [
      'Assessment restricted strictly to authorized network CIDR boundary.',
      'Denial of service (DoS), SYN floods, and permanent disk destruction are strictly forbidden.',
      'All extracted credentials and tickets must be captured with SHA-256 cryptographic hashes in Evidence Vault.',
      'Out-of-scope external targets are actively blocked by the server-side Scope Guard.'
    ]
  });

  const [testIp, setTestIp] = useState<string>('192.168.56.10');
  const [verificationResult, setVerificationResult] = useState<{
    tested: boolean;
    allowed: boolean;
    message: string;
    ip: string;
  } | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  // Edit scope state
  const [isEditingScope, setIsEditingScope] = useState<boolean>(false);
  const [newCidrInput, setNewCidrInput] = useState<string>('192.168.56.0/24');
  const [newAssessmentName, setNewAssessmentName] = useState<string>('');
  const [isSavingScope, setIsSavingScope] = useState<boolean>(false);
  const [scopeSaveStatus, setScopeSaveStatus] = useState<{ success?: boolean; message?: string } | null>(null);

  // Load scope on mount
  useEffect(() => {
    fetch('/api/scope')
      .then(res => res.json())
      .then(data => {
        if (data && data.authorizedCidr) {
          setScopeConfig(data);
          setNewCidrInput(data.authorizedCidr);
          setNewAssessmentName(data.assessmentName || '');
          setTestIp(data.networkAddress ? `${data.networkAddress.split('.').slice(0, 3).join('.')}.10` : '192.168.56.10');
        }
      })
      .catch(err => console.error('Failed to load lab scope:', err));
  }, []);

  const handleTestIp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testIp.trim()) return;

    setIsVerifying(true);
    try {
      const res = await fetch('/api/scope/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetIp: testIp.trim() }),
      });
      const data = await res.json();

      setVerificationResult({
        tested: true,
        allowed: data.allowed,
        message: data.reason || (data.allowed ? 'IP is inside authorized scope' : 'IP rejected'),
        ip: testIp.trim()
      });
    } catch (err: any) {
      setVerificationResult({
        tested: true,
        allowed: false,
        message: `Network error verifying scope: ${err.message}`,
        ip: testIp.trim()
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSaveScope = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCidrInput.trim()) return;

    setIsSavingScope(true);
    setScopeSaveStatus(null);
    try {
      const res = await fetch('/api/scope', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorizedCidr: newCidrInput.trim(),
          assessmentName: newAssessmentName.trim() || scopeConfig.assessmentName
        })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setScopeConfig(data.scope);
        setIsEditingScope(false);
        setScopeSaveStatus({ success: true, message: `Authorized scope changed to ${data.scope.authorizedCidr}` });
        if (onScopeUpdated) {
          onScopeUpdated(data.scope.authorizedCidr);
        }
        setVerificationResult(null);
      } else {
        setScopeSaveStatus({ success: false, message: data.error || 'Failed to update scope' });
      }
    } catch (err: any) {
      setScopeSaveStatus({ success: false, message: `Error updating scope: ${err.message}` });
    } finally {
      setIsSavingScope(false);
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Scope Header Card */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100">
                ASSESSMENT SCOPE &amp; BOUNDARY ENFORCEMENT ENGINE
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-700">
                ACTIVE CIDR GUARD
              </span>
            </div>
            <p className="text-neutral-400 text-xs mt-0.5">
              Authorized CIDR: <strong className="text-emerald-400">{scopeConfig.authorizedCidr}</strong> | Net: <span className="text-neutral-300">{scopeConfig.networkAddress}</span> | Mask: <span className="text-neutral-300">{scopeConfig.subnetMask}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsEditingScope(!isEditingScope);
              setScopeSaveStatus(null);
            }}
            className="px-3 py-1.5 rounded bg-cyan-900/60 hover:bg-cyan-800 text-cyan-200 border border-cyan-700 flex items-center gap-1.5 font-bold cursor-pointer transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>{isEditingScope ? 'Close Editor' : 'Change Target IP / CIDR Scope'}</span>
          </button>
        </div>
      </div>

      {/* Scope Editor Drawer if Active */}
      {isEditingScope && (
        <form onSubmit={handleSaveScope} className={`p-4 rounded-xl border border-cyan-700/60 bg-cyan-950/30 space-y-4`}>
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-cyan-400" />
              <span>Modify Authorized Assessment Boundary (Any Subnet / Host IP)</span>
            </h3>
            <span className="text-[11px] text-neutral-400">
              Bitwise 32-bit CIDR Enforcement
            </span>
          </div>

          <p className="text-xs text-neutral-300 leading-relaxed">
            ADStrike is <strong>NOT</strong> locked to a single IP address. You can configure it to target <strong>any IP address, subnet, or home lab</strong> you own and are authorized to assess (e.g. <code>10.0.0.0/24</code>, <code>192.168.1.0/24</code>, <code>172.16.10.0/24</code>, or a single host like <code>192.168.1.50/32</code>).
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-neutral-400 mb-1 text-[11px]">Authorized Subnet CIDR (Required):</label>
              <input
                type="text"
                value={newCidrInput}
                onChange={(e) => setNewCidrInput(e.target.value)}
                placeholder="e.g. 10.0.0.0/24 or 192.168.1.0/24"
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-2 text-emerald-300 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-neutral-400 mb-1 text-[11px]">Assessment Name / Scope Label:</label>
              <input
                type="text"
                value={newAssessmentName}
                onChange={(e) => setNewAssessmentName(e.target.value)}
                placeholder="e.g. Internal Home Lab Active Directory"
                className="w-full bg-neutral-950 border border-neutral-700 rounded px-3 py-2 text-neutral-200 font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {/* Quick presets */}
          <div className="flex flex-wrap items-center gap-2 text-[10px]">
            <span className="text-neutral-400">Quick Presets:</span>
            {[
              { label: 'VirtualBox (192.168.56.0/24)', cidr: '192.168.56.0/24' },
              { label: 'Home LAN (192.168.1.0/24)', cidr: '192.168.1.0/24' },
              { label: 'Enterprise Lab (10.0.0.0/24)', cidr: '10.0.0.0/24' },
              { label: 'AD Domain Subnet (172.16.0.0/24)', cidr: '172.16.0.0/24' },
              { label: 'Localhost / Loopback (127.0.0.1/32)', cidr: '127.0.0.1/32' },
            ].map(p => (
              <button
                key={p.cidr}
                type="button"
                onClick={() => setNewCidrInput(p.cidr)}
                className="px-2 py-0.5 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 cursor-pointer"
              >
                {p.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              disabled={isSavingScope}
              className="px-4 py-2 rounded bg-emerald-700 hover:bg-emerald-600 text-white font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSavingScope ? 'Updating Guard...' : 'Apply Scope & Update Rules of Engagement'}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsEditingScope(false)}
              className="px-3 py-2 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 cursor-pointer"
            >
              Cancel
            </button>
          </div>

          {scopeSaveStatus && (
            <div className={`p-2.5 rounded border text-xs ${scopeSaveStatus.success ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300' : 'bg-red-950/60 border-red-700 text-red-300'}`}>
              {scopeSaveStatus.message}
            </div>
          )}
        </form>
      )}

      {/* Two Column Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Scope Metrics & Subnet Bounds */}
        <div className="lg:col-span-6 space-y-6">
          <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-4`}>
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              <span>Subnet Boundary Specifications</span>
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-neutral-800">
                <span className="text-neutral-400">Target Network CIDR:</span>
                <span className="font-bold text-emerald-400">{scopeConfig.authorizedCidr}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-neutral-800">
                <span className="text-neutral-400">Subnet Mask:</span>
                <span className="text-neutral-200">{scopeConfig.subnetMask}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-neutral-800">
                <span className="text-neutral-400">Network Address:</span>
                <span className="text-neutral-200">{scopeConfig.networkAddress}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-neutral-800">
                <span className="text-neutral-400">Broadcast Address:</span>
                <span className="text-neutral-200">{scopeConfig.broadcastAddress}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-neutral-400">Permitted Usable Host Range:</span>
                <span className="font-bold text-cyan-300">{scopeConfig.networkAddress} — {scopeConfig.broadcastAddress}</span>
              </div>
            </div>
          </div>

          {/* Rules of Engagement */}
          <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-3`}>
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-emerald-400" />
              <span>Rules of Engagement (RoE)</span>
            </h3>
            <ul className="space-y-2 text-xs text-neutral-300">
              {scopeConfig.rulesOfEngagement.map((rule, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right Column: Live Scope Guard Verifier & Allowlist */}
        <div className="lg:col-span-6 space-y-6">
          <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-4`}>
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Live Scope Guard Bitwise Verifier</span>
            </h3>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Test any target IP against the active Scope Guard. If an IP falls outside <code>{scopeConfig.authorizedCidr}</code>, the Express server middleware strictly rejects it with <code>HTTP 403 TARGET_OUT_OF_SCOPE</code>.
            </p>

            <form onSubmit={handleTestIp} className="flex gap-2">
              <input
                type="text"
                value={testIp}
                onChange={(e) => setTestIp(e.target.value)}
                placeholder={`e.g. ${scopeConfig.networkAddress ? scopeConfig.networkAddress.replace(/\.0$/, '.10') : '10.0.0.10'} or 8.8.8.8`}
                className="flex-1 bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-neutral-100 font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
              <button
                type="submit"
                disabled={isVerifying}
                className="px-4 py-2 rounded bg-cyan-700 hover:bg-cyan-600 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isVerifying ? 'Checking...' : 'Verify IP'}</span>
              </button>
            </form>

            {/* Quick Test Presets */}
            <div className="flex items-center gap-2 text-[10px] text-neutral-400">
              <span>Test:</span>
              <button
                type="button"
                onClick={() => setTestIp(scopeConfig.networkAddress ? scopeConfig.networkAddress.replace(/\.0$/, '.10') : '192.168.56.10')}
                className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white cursor-pointer"
              >
                In-Scope Target
              </button>
              <button
                type="button"
                onClick={() => setTestIp('8.8.8.8')}
                className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-red-400 hover:text-red-300 cursor-pointer"
              >
                8.8.8.8 (Out-of-Scope)
              </button>
              <button
                type="button"
                onClick={() => setTestIp('1.1.1.1')}
                className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                1.1.1.1 (Out-of-Scope)
              </button>
            </div>

            {/* Verification Result Display */}
            {verificationResult && (
              <div
                className={`p-3 rounded-lg border text-xs space-y-1 ${
                  verificationResult.allowed
                    ? 'bg-emerald-950/60 border-emerald-700/60 text-emerald-200'
                    : 'bg-red-950/60 border-red-700/60 text-red-200'
                }`}
              >
                <div className="flex items-center gap-2 font-bold">
                  {verificationResult.allowed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-400" />
                  )}
                  <span>
                    {verificationResult.allowed ? 'PASS: TARGET AUTHORIZED IN SCOPE' : 'BLOCKED: HARD OUT-OF-SCOPE VIOLATION'}
                  </span>
                </div>
                <div className="text-[11px] opacity-90 pl-6">
                  {verificationResult.message}
                </div>
              </div>
            )}
          </div>

          {/* Authorized Hosts Catalog */}
          <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-3`}>
            <h3 className="text-xs font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Current Allowlist Targets</span>
            </h3>
            <div className="space-y-1.5 text-xs text-neutral-300">
              {scopeConfig.allowedHosts.map((h, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded bg-neutral-900/60 border border-neutral-850">
                  <span className="font-mono">{h}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                    AUTHORIZED
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
