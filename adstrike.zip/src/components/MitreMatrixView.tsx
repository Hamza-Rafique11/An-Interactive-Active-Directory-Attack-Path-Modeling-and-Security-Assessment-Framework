import React, { useState } from 'react';
import { ShieldAlert, CheckCircle2, AlertTriangle, ExternalLink, Filter, Search, Tag } from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface MitreMatrixViewProps {
  template: InterfaceTemplate;
  onSelectTechnique?: (techniqueId: string) => void;
}

interface MatrixColumn {
  tactic: string;
  tacticId: string;
  techniques: {
    id: string;
    name: string;
    status: 'VALIDATED_LAB' | 'SIMULATED' | 'PLANNED';
    severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
    tool: string;
    desc: string;
  }[];
}

const ATTACK_TACTICS: MatrixColumn[] = [
  {
    tactic: 'Reconnaissance',
    tacticId: 'TA0043',
    techniques: [
      {
        id: 'T1595.001',
        name: 'Active Scanning: IP Blocks',
        status: 'VALIDATED_LAB',
        severity: 'LOW',
        tool: 'Node TCP Prober / ARP',
        desc: 'Subnet sweeps to identify active Windows hosts on host-only subnet.'
      },
      {
        id: 'T1592',
        name: 'Gather Victim Host Info',
        status: 'VALIDATED_LAB',
        severity: 'LOW',
        tool: 'Nmap / Socket Banner Grab',
        desc: 'Enumerating OS versions, NetBIOS names, and domain membership.'
      }
    ]
  },
  {
    tactic: 'Discovery',
    tacticId: 'TA0007',
    techniques: [
      {
        id: 'T1087.002',
        name: 'Account Discovery: Domain Account',
        status: 'VALIDATED_LAB',
        severity: 'MEDIUM',
        tool: 'LDAP Query (sAMAccountType)',
        desc: 'Harvesting user objects, UAC flags, and adminCount attributes.'
      },
      {
        id: 'T1069.002',
        name: 'Permission Groups: Domain Groups',
        status: 'VALIDATED_LAB',
        severity: 'HIGH',
        tool: 'LDAP Group Enumeration',
        desc: 'Locating nested members of Domain Admins and custom administrative groups.'
      },
      {
        id: 'T1018',
        name: 'Remote System Discovery',
        status: 'VALIDATED_LAB',
        severity: 'MEDIUM',
        tool: 'SMB2 Ping / Nmap',
        desc: 'Locating Domain Controllers and member servers.'
      }
    ]
  },
  {
    tactic: 'Credential Access',
    tacticId: 'TA0006',
    techniques: [
      {
        id: 'T1558.003',
        name: 'Steal/Forge Kerberos: Kerberoasting',
        status: 'VALIDATED_LAB',
        severity: 'CRITICAL',
        tool: 'GetUserSPNs.py (TGS-REP)',
        desc: 'Extracting service ticket hashes for offline cracking (svc_mssql).'
      },
      {
        id: 'T1558.004',
        name: 'Steal/Forge Kerberos: AS-REP Roasting',
        status: 'VALIDATED_LAB',
        severity: 'HIGH',
        tool: 'GetNPUsers.py (DONT_REQ_PREAUTH)',
        desc: 'Harvesting AS-REP hashes from accounts without Kerberos pre-authentication.'
      },
      {
        id: 'T1003.006',
        name: 'OS Credential Dumping: DCSync',
        status: 'VALIDATED_LAB',
        severity: 'CRITICAL',
        tool: 'secretsdump.py (DRSUAPI)',
        desc: 'Simulating Domain Controller replication to dump NTDS.dit password hashes.'
      }
    ]
  },
  {
    tactic: 'Privilege Escalation',
    tacticId: 'TA0004',
    techniques: [
      {
        id: 'T1558.001',
        name: 'Unconstrained Kerberos Delegation',
        status: 'VALIDATED_LAB',
        severity: 'CRITICAL',
        tool: 'Rubeus / Impacket',
        desc: 'Exploiting TRUSTED_FOR_DELEGATION on WIN-SRV-01 to intercept DC TGTs.'
      },
      {
        id: 'T1078.002',
        name: 'Valid Accounts: Domain Accounts',
        status: 'VALIDATED_LAB',
        severity: 'HIGH',
        tool: 'Pass-the-Hash',
        desc: 'Reusing cracked service account credentials across member servers.'
      }
    ]
  },
  {
    tactic: 'Lateral Movement',
    tacticId: 'TA0008',
    techniques: [
      {
        id: 'T1021.002',
        name: 'Remote Services: SMB/Windows Admin Shares',
        status: 'VALIDATED_LAB',
        severity: 'CRITICAL',
        tool: 'wmiexec.py / psexec.py',
        desc: 'Remote command execution via WMI DCOM and SMB Named Pipes using NTLM hashes.'
      },
      {
        id: 'T1557.001',
        name: 'Adversary-in-the-Middle: LLMNR/NBT-NS Poisoning',
        status: 'SIMULATED',
        severity: 'HIGH',
        tool: 'Responder / ntlmrelayx',
        desc: 'Poisoning multicast name resolution to capture NetNTLMv2 hashes.'
      }
    ]
  }
];

export const MitreMatrixView: React.FC<MitreMatrixViewProps> = ({ template, onSelectTechnique }) => {
  const [selectedTechnique, setSelectedTechnique] = useState<any>(null);
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Header Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-red-950 text-red-400 border border-red-800">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100">
                MITRE ATT&amp;CK® ENTERPRISE MATRIX FOR ACTIVE DIRECTORY
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-800 text-neutral-300 border border-neutral-700">
                LAB COVERAGE: 11 TECHNIQUES
              </span>
            </div>
            <p className="text-neutral-400 text-xs mt-0.5">
              Definitive mapping of simulated offensive techniques to authorized laboratory validation vectors and defense detection logic.
            </p>
          </div>
        </div>

        {/* Severity Filter */}
        <div className="flex items-center gap-1.5">
          {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-2.5 py-1 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                filterSeverity === sev
                  ? 'bg-neutral-800 text-neutral-100 border border-neutral-600'
                  : 'bg-neutral-950 text-neutral-400 hover:text-neutral-200 border border-neutral-900'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* ATT&CK Columns Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
        {ATTACK_TACTICS.map((col) => {
          const matchingTechniques = col.techniques.filter(
            (t) => filterSeverity === 'ALL' || t.severity === filterSeverity
          );

          return (
            <div
              key={col.tacticId}
              className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col overflow-hidden`}
            >
              {/* Column Header */}
              <div className="p-3 bg-neutral-900/90 border-b border-neutral-800 space-y-0.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-neutral-400 uppercase">
                    {col.tacticId}
                  </span>
                  <span className="text-[10px] text-neutral-400 font-mono">
                    ({matchingTechniques.length})
                  </span>
                </div>
                <h3 className="font-bold text-neutral-200 text-xs truncate">
                  {col.tactic}
                </h3>
              </div>

              {/* Technique Cards */}
              <div className="p-2 space-y-2 flex-1">
                {matchingTechniques.map((tech) => {
                  const isSelected = selectedTechnique?.id === tech.id;
                  return (
                    <div
                      key={tech.id}
                      onClick={() => setSelectedTechnique(tech)}
                      className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-neutral-900 border-red-500 shadow-md ring-1 ring-red-500/40'
                          : 'bg-neutral-950/70 border-neutral-850 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-bold text-cyan-400 font-mono">
                          {tech.id}
                        </span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                            tech.severity === 'CRITICAL'
                              ? 'bg-red-950 text-red-300 border border-red-800'
                              : tech.severity === 'HIGH'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-neutral-850 text-neutral-300'
                          }`}
                        >
                          {tech.severity}
                        </span>
                      </div>

                      <div className="font-bold text-neutral-200 text-[11px] leading-snug">
                        {tech.name}
                      </div>

                      <div className="mt-1.5 flex items-center justify-between text-[10px]">
                        <span className="text-neutral-400 truncate max-w-[120px]">
                          {tech.tool}
                        </span>
                        <span
                          className={`px-1 py-0.2 rounded text-[9px] font-bold ${
                            tech.status === 'VALIDATED_LAB'
                              ? 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60'
                              : 'bg-neutral-900 text-neutral-400'
                          }`}
                        >
                          {tech.status === 'VALIDATED_LAB' ? 'VALIDATED' : 'SIMULATED'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Deep Technique Drawer / Details */}
      {selectedTechnique && (
        <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-3 shadow-xl`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-xs font-bold bg-red-950 text-red-300 border border-red-800">
                {selectedTechnique.id}
              </span>
              <h3 className="text-sm font-bold text-neutral-100">
                {selectedTechnique.name}
              </h3>
            </div>

            <button
              onClick={() => setSelectedTechnique(null)}
              className="text-neutral-400 hover:text-neutral-200 text-xs cursor-pointer"
            >
              Close Details
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px]">
            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-850 space-y-1">
              <span className="text-neutral-400 text-[10px] font-bold block">TACTIC &amp; STATUS</span>
              <div className="text-neutral-200 font-bold">{selectedTechnique.status}</div>
              <div className="text-neutral-400">Severity: {selectedTechnique.severity}</div>
            </div>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-850 space-y-1">
              <span className="text-neutral-400 text-[10px] font-bold block">EXECUTION TOOLING</span>
              <div className="text-cyan-300 font-bold">{selectedTechnique.tool}</div>
              <div className="text-neutral-400">Target Segment: 192.168.56.0/24</div>
            </div>

            <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-850 space-y-1">
              <span className="text-neutral-400 text-[10px] font-bold block">EVIDENCE VAULT INTEGRATION</span>
              <div className="text-emerald-400 font-bold">SHA-256 Checksum Logged</div>
              <div className="text-neutral-400">Replication Proof Recorded</div>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 text-[11px] text-neutral-300 leading-relaxed">
            <strong className="text-neutral-100">Technique Profile &amp; Detection Strategy: </strong>
            {selectedTechnique.desc} Event logs should monitor Windows Event ID 4769 (A Kerberos service ticket was requested with Ticket Encryption Type 0x17) and Event ID 4662 (Operation was performed on an Active Directory object with DS-Replication-Get-Changes-All extended right).
          </div>
        </div>
      )}
    </div>
  );
};
