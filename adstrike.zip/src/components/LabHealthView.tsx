import React, { useState, useEffect } from 'react';
import {
  Activity,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Terminal,
  Shield,
  Server,
  Network,
  Cpu,
  Radio,
  FileCheck
} from 'lucide-react';
import { InterfaceTemplate, LabHealthStatus } from '../types';

interface LabHealthViewProps {
  template: InterfaceTemplate;
}

export const LabHealthView: React.FC<LabHealthViewProps> = ({ template }) => {
  const [health, setHealth] = useState<LabHealthStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [testIp, setTestIp] = useState('192.168.56.10');
  const [probeResult, setProbeResult] = useState<any>(null);
  const [probing, setProbing] = useState(false);

  const fetchHealth = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/lab/health');
      if (res.ok) {
        const data = await res.json();
        setHealth(data);
      }
    } catch (err) {
      console.error('Failed to fetch lab health:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealth();
  }, []);

  const handleTestProbe = async () => {
    setProbing(true);
    setProbeResult(null);
    try {
      const res = await fetch('/api/enumeration/ports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: testIp, flags: '-p 88,135,389,445' })
      });
      const data = await res.json();
      setProbeResult(data);
    } catch (err: any) {
      setProbeResult({ error: err.message });
    } finally {
      setProbing(false);
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgPanel} flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg`}>
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-neutral-100">
                LAB RUNTIME HEALTH &amp; TOOL INTEGRITY MONITOR
              </h2>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                health?.overallStatus === 'HEALTHY'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                  : 'bg-amber-950 text-amber-300 border border-amber-700'
              }`}>
                {health?.overallStatus || 'CHECKING...'}
              </span>
            </div>
            <p className="text-neutral-400 text-xs mt-0.5">
              Real-time audit of local offensive binaries, raw TCP socket engine, and network boundary enforcement.
            </p>
          </div>
        </div>

        <button
          onClick={fetchHealth}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-neutral-850 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Diagnostics</span>
        </button>
      </div>

      {/* Grid: Tool Matrix & Probe Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Tool Status List (2 Cols) */}
        <div className={`lg:col-span-2 rounded-xl border ${template.palette.border} ${template.palette.bgCard} p-4 space-y-4`}>
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <h3 className="font-bold text-neutral-200 text-xs flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>OFFENSIVE TOOLING &amp; RUNTIME DEPENDENCIES</span>
            </h3>
            <span className="text-[10px] text-neutral-400">
              Host Platform: {health?.platform || 'linux'}
            </span>
          </div>

          <div className="space-y-2">
            {health?.tools?.map((tool) => (
              <div
                key={tool.name}
                className="p-3 rounded-lg bg-neutral-950/80 border border-neutral-800/80 flex items-center justify-between gap-3"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-neutral-100">{tool.name}</span>
                    <span className="text-[10px] font-mono text-neutral-400">
                      {tool.command}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-400 font-mono">
                    {tool.notes}
                  </div>
                  {tool.version && (
                    <div className="text-[10px] text-neutral-400 font-mono">
                      Output: <code className="text-emerald-400">{tool.version}</code>
                    </div>
                  )}
                </div>

                <div className="flex-shrink-0">
                  {tool.installed ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      INSTALLED
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                      <AlertTriangle className="w-3 h-3 text-amber-400" />
                      FALLBACK READY
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Fallback Notice */}
          <div className="p-3 rounded-lg bg-neutral-900/50 border border-neutral-800 text-[11px] text-neutral-400 space-y-1">
            <span className="font-bold text-neutral-200">Execution Guarantee:</span>
            <p>
              When external command-line binaries (like Nmap or Impacket) are absent in sandboxed container environments, ADStrike automatically engages its native Node.js <code className="text-cyan-300">net.Socket</code> TCP probing engine and raw SMB2 negotiation handshake logic. Every action is categorized with an honest <code className="text-emerald-300">[REAL]</code> or <code className="text-amber-300">[SIMULATED]</code> tag.
            </p>
          </div>
        </div>

        {/* Right Col: Scope Guard & Probe Diagnostics */}
        <div className="space-y-4">
          {/* Scope Guard Status Box */}
          <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgCard} p-4 space-y-3`}>
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-800">
              <Shield className="w-4 h-4 text-emerald-400" />
              <h3 className="font-bold text-neutral-200 text-xs">
                SCOPE GUARD ENFORCEMENT
              </h3>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between items-center py-1 border-b border-neutral-850">
                <span className="text-neutral-400">Authorized CIDR:</span>
                <span className="text-emerald-400 font-bold">{health?.scope?.authorizedCidr || '192.168.56.0/24'}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-neutral-850">
                <span className="text-neutral-400">Strict Enforcement:</span>
                <span className="text-emerald-300 font-bold">ACTIVE (Node Bitwise)</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-neutral-850">
                <span className="text-neutral-400">Out-of-Scope Drops:</span>
                <span className="text-neutral-200 font-bold">403 FORBIDDEN</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-neutral-400">Audit Logging:</span>
                <span className="text-neutral-200 font-bold">IMMUTABLE JSON</span>
              </div>
            </div>
          </div>

          {/* Direct Socket Prober */}
          <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgCard} p-4 space-y-3`}>
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-800">
              <Radio className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-neutral-200 text-xs">
                REAL-TIME SOCKET PROBER
              </h3>
            </div>

            <p className="text-[10px] text-neutral-400">
              Test raw TCP handshake directly through Node.js net.Socket to verify target reachability.
            </p>

            <div className="space-y-2">
              <input
                type="text"
                value={testIp}
                onChange={(e) => setTestIp(e.target.value)}
                placeholder="Target IP (e.g. 192.168.56.10)"
                className="w-full bg-neutral-950 border border-neutral-800 rounded px-2.5 py-1.5 text-xs text-neutral-200 font-mono outline-none"
              />
              <button
                onClick={handleTestProbe}
                disabled={probing}
                className="w-full py-1.5 rounded bg-cyan-800 hover:bg-cyan-700 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${probing ? 'animate-spin' : ''}`} />
                <span>{probing ? 'PROBING SOCKETS...' : 'PROBE TARGET PORTS'}</span>
              </button>
            </div>

            {probeResult && (
              <div className="p-2.5 rounded bg-neutral-950 border border-neutral-800 space-y-1.5 text-[10px]">
                {probeResult.error ? (
                  <div className="text-red-400 font-bold">Error: {probeResult.error}</div>
                ) : (
                  <>
                    <div className="flex justify-between text-neutral-400">
                      <span>Execution Mode:</span>
                      <span className="text-emerald-400 font-bold">{probeResult.executionMode || 'REAL'}</span>
                    </div>
                    <div className="flex justify-between text-neutral-400">
                      <span>Target:</span>
                      <span className="text-neutral-200">{probeResult.target}</span>
                    </div>
                    <div className="flex justify-between text-neutral-400">
                      <span>Open Ports Found:</span>
                      <span className="text-cyan-300 font-bold">{probeResult.ports?.length || 0}</span>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
