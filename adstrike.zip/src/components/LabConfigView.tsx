import React, { useState, useEffect } from 'react';
import { Sliders, Copy, CheckCircle2, Terminal, Shield, Laptop, Network, ExternalLink } from 'lucide-react';
import { InterfaceTemplate } from '../types';

interface LabConfigViewProps {
  template: InterfaceTemplate;
}

export const LabConfigView: React.FC<LabConfigViewProps> = ({
  template,
}) => {
  const [labPresets, setLabPresets] = useState<any>(null);
  const [copiedScript, setCopiedScript] = useState(false);
  const [testIp, setTestIp] = useState('192.168.56.10');
  const [testResult, setTestResult] = useState<any>(null);

  useEffect(() => {
    fetch('/api/lab/presets')
      .then(res => res.json())
      .then(data => setLabPresets(data))
      .catch(() => {});
  }, []);

  const copyScript = () => {
    if (labPresets?.activeDirectorySetupScript) {
      navigator.clipboard.writeText(labPresets.activeDirectorySetupScript);
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2000);
    }
  };

  const handleTestIp = async () => {
    try {
      const res = await fetch('/api/scope/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetIp: testIp })
      });
      const data = await res.json();
      setTestResult(data);
    } catch {
      // Error
    }
  };

  return (
    <div className="space-y-4 font-mono text-xs">
      {/* Banner */}
      <div className={`p-4 rounded-xl border ${template.palette.border} ${template.palette.bgCard} space-y-2`}>
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded bg-neutral-800 border border-neutral-700 text-neutral-300">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-neutral-100 uppercase tracking-wide">
              ISOLATED LAB ENVIRONMENT SPECIFICATION & BUILD BLUEPRINTS
            </h3>
            <p className="text-[11px] text-neutral-400">
              VirtualBox / VMware Host-Only networking parameters and automated vulnerable AD provisioning
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* VirtualBox / VMware Setup Instructions */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-3 shadow-xl`}>
          <div className="flex items-center gap-2 pb-2 border-b border-neutral-800">
            <Network className="w-4 h-4 text-emerald-400" />
            <h4 className="font-bold text-neutral-200 text-xs">
              HOST-ONLY NETWORK ARCHITECTURE (192.168.56.0/24)
            </h4>
          </div>

          <div className="p-3 rounded bg-neutral-950 border border-neutral-850 space-y-2 text-[11px]">
            <div className="flex justify-between text-neutral-400">
              <span>Adapter Name:</span>
              <span className="text-neutral-200 font-bold">vboxnet0 / vmnet1 (Host-Only)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Subnet Mask:</span>
              <span className="text-neutral-200 font-mono">255.255.255.0 (/24)</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Gateway / Host IP:</span>
              <span className="text-emerald-400 font-mono">192.168.56.1</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>DHCP Server:</span>
              <span className="text-amber-400 font-mono">Disabled (Use static IP addressing)</span>
            </div>
          </div>

          <div className="space-y-1.5 text-[11px] text-neutral-300">
            <span className="font-bold text-neutral-200 block text-xs">Setup Steps:</span>
            <ol className="list-decimal list-inside space-y-1.5 text-neutral-400">
              {labPresets?.virtualBoxSetupInstructions?.map((step: string, idx: number) => (
                <li key={idx} className="leading-relaxed">{step}</li>
              ))}
            </ol>
          </div>

          {/* Scope Guard Diagnostic Tester */}
          <div className="pt-3 border-t border-neutral-800 space-y-2">
            <span className="font-bold text-neutral-200 text-xs block">
              SCOPE GUARD REAL-TIME CHECK:
            </span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={testIp}
                onChange={(e) => setTestIp(e.target.value)}
                placeholder="Enter IP (e.g. 192.168.56.10 or 8.8.8.8)"
                className="flex-1 bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-neutral-200 font-mono outline-none"
              />
              <button
                onClick={handleTestIp}
                className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold cursor-pointer"
              >
                Test Scope
              </button>
            </div>

            {testResult && (
              <div className={`p-2 rounded text-[10px] font-bold flex items-center gap-1.5 ${
                testResult.allowed
                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                  : 'bg-red-950/80 text-red-300 border border-red-800/60'
              }`}>
                {testResult.allowed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Shield className="w-3.5 h-3.5" />}
                <span>{testResult.reason}</span>
              </div>
            )}
          </div>
        </div>

        {/* PowerShell Vulnerable AD Seeder */}
        <div className={`rounded-xl border ${template.palette.border} ${template.palette.bgPanel} p-4 space-y-3 shadow-xl flex flex-col justify-between`}>
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <h4 className="font-bold text-neutral-200 text-xs">
                  POWERSHELL AD PROVISIONING SCRIPT
                </h4>
              </div>
              <button
                onClick={copyScript}
                className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 flex items-center gap-1 text-[10px] font-bold cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>{copiedScript ? 'COPIED!' : 'COPY POWERSHELL'}</span>
              </button>
            </div>

            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Run this script within an elevated PowerShell console on Windows Server 2022 to install AD DS, configure the domain <strong className="text-neutral-200">adstrike.local</strong>, and create vulnerable SPN and pre-auth test accounts.
            </p>

            <div className="p-3 rounded bg-neutral-950 border border-neutral-850 max-h-72 overflow-y-auto">
              <pre className="text-[10px] text-cyan-300 leading-relaxed font-mono whitespace-pre-wrap">
                {labPresets?.activeDirectorySetupScript}
              </pre>
            </div>
          </div>

          <div className="pt-3 border-t border-neutral-800 flex items-center justify-between text-[10px] text-neutral-500">
            <span>Domain: adstrike.local</span>
            <span className="text-emerald-400 font-bold">READY FOR RECON</span>
          </div>
        </div>
      </div>
    </div>
  );
};
